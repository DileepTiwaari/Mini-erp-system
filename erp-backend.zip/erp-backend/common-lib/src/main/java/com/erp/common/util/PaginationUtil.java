package com.erp.common.util;

import com.erp.common.response.PageResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.util.List;
import java.util.function.Function;

public class PaginationUtil {

    private PaginationUtil() {
    }

    public static Pageable buildPageable(int page, int size) {
        return PageRequest.of(page, size);
    }

    public static Pageable buildPageable(int page, int size, String sortBy, String sortDirection) {
        if (sortBy == null || sortBy.isBlank()) {
            return PageRequest.of(page, size);
        }
        Sort.Direction direction = "DESC".equalsIgnoreCase(sortDirection)
                ? Sort.Direction.DESC
                : Sort.Direction.ASC;
        return PageRequest.of(page, size, Sort.by(direction, sortBy));
    }

    public static <E, D> PageResponse<D> toPageResponse(Page<E> entityPage, Function<E, D> mapper) {
        List<D> content = entityPage.getContent().stream().map(mapper).toList();
        return PageResponse.<D>builder()
                .content(content)
                .pageNumber(entityPage.getNumber())
                .pageSize(entityPage.getSize())
                .totalElements(entityPage.getTotalElements())
                .totalPages(entityPage.getTotalPages())
                .last(entityPage.isLast())
                .build();
    }
}