package com.erp.common.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;

public class OpenApiBaseConfig {

    private OpenApiBaseConfig() {
    }

    /**
     * Each service's own OpenApiConfig can call this to get a pre-filled
     * OpenAPI object, then override title/description as needed.
     */
    public static OpenAPI baseOpenAPI(String serviceTitle, String serviceDescription) {
        return new OpenAPI()
                .info(new Info()
                        .title(serviceTitle)
                        .description(serviceDescription)
                        .version("v1.0.0")
                        .contact(new Contact()
                                .name("Shiv Furniture Works - Mini ERP")
                                .email("support@shivfurniture.example.com")));
    }
}