package com.erp.common.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

public class ReferenceNumberGenerator {

    private static final AtomicInteger COUNTER = new AtomicInteger(1);
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd");

    private ReferenceNumberGenerator() {
    }

    /**
     * Generates a reference number like PO-20260620-0001
     *
     * @param prefix e.g. "PO", "SO", "MO", "GRN"
     */
    public static String generate(String prefix) {
        String datePart = LocalDate.now().format(DATE_FORMAT);
        int sequence = COUNTER.getAndIncrement();
        return String.format("%s-%s-%04d", prefix, datePart, sequence);
    }

    /**
     * Resets the in-memory counter. Intended for tests only —
     * NOT safe to call in production since it does not coordinate across
     * multiple instances or persist across restarts.
     */
    public static void resetCounter() {
        COUNTER.set(1);
    }
}