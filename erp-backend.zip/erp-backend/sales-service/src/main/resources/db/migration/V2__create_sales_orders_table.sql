CREATE TABLE sales_orders (
                              id BIGINT AUTO_INCREMENT PRIMARY KEY,
                              so_number VARCHAR(50) NOT NULL UNIQUE,
                              customer_id BIGINT NOT NULL,
                              status VARCHAR(30) NOT NULL,
                              order_date DATE NOT NULL,
                              total_amount DECIMAL(15,2),
                              created_by VARCHAR(255),
                              created_at DATETIME NOT NULL,
                              updated_at DATETIME NOT NULL,
                              CONSTRAINT fk_sales_order_customer FOREIGN KEY (customer_id) REFERENCES customers(id)
);