CREATE TABLE customers (
                           id BIGINT AUTO_INCREMENT PRIMARY KEY,
                           name VARCHAR(255) NOT NULL,
                           email VARCHAR(255),
                           phone VARCHAR(50),
                           address VARCHAR(500),
                           active BOOLEAN NOT NULL DEFAULT TRUE,
                           created_at DATETIME NOT NULL,
                           updated_at DATETIME NOT NULL
);