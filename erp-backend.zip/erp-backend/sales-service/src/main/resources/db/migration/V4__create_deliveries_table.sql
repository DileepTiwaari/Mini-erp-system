CREATE TABLE deliveries (
                            id BIGINT AUTO_INCREMENT PRIMARY KEY,
                            delivery_number VARCHAR(50) NOT NULL UNIQUE,
                            sales_order_id BIGINT NOT NULL,
                            status VARCHAR(30) NOT NULL,
                            delivery_date DATE NOT NULL,
                            created_at DATETIME NOT NULL,
                            CONSTRAINT fk_delivery_sales_order FOREIGN KEY (sales_order_id) REFERENCES sales_orders(id)
);

CREATE TABLE delivery_items (
                                delivery_id BIGINT NOT NULL,
                                sales_order_line_id BIGINT NOT NULL,
                                product_id BIGINT NOT NULL,
                                delivered_quantity INT NOT NULL,
                                CONSTRAINT fk_delivery_item_delivery FOREIGN KEY (delivery_id) REFERENCES deliveries(id) ON DELETE CASCADE
);