package com.erp.sales_service.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DeliveryItemResponse {

    private Long salesOrderLineId;
    private Long productId;
    private Integer deliveredQuantity;
}