package com.erp.sales_service.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.*;

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DeliveryItem {

    @Column(name = "sales_order_line_id", nullable = false)
    private Long salesOrderLineId;

    @Column(name = "product_id", nullable = false)
    private Long productId;

    @Column(name = "delivered_quantity", nullable = false)
    private Integer deliveredQuantity;
}