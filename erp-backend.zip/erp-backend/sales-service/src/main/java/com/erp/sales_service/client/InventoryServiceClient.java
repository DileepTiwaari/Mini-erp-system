package com.erp.sales_service.client;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "inventory-service")
public interface InventoryServiceClient {

    @GetMapping("/api/v1/stock/{productId}")
    StockInfo getStock(@PathVariable("productId") Long productId);

    @PostMapping("/api/v1/stock/reserve")
    void reserveStock(@RequestBody StockChangeRequest request);

    @PostMapping("/api/v1/stock/release")
    void releaseStock(@RequestBody StockChangeRequest request);

    @PostMapping("/api/v1/stock/decrease")
    void decreaseStock(@RequestBody StockChangeRequest request);

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    class StockInfo {
        private Long productId;
        private Integer onHandQuantity;
        private Integer reservedQuantity;
        private Integer freeToUseQuantity;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    class StockChangeRequest {
        private Long productId;
        private Integer quantity;
        private String referenceType;
        private String referenceNumber;
    }
}