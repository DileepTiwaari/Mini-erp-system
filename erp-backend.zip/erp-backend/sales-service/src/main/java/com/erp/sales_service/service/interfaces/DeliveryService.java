package com.erp.sales_service.service.interfaces;

import com.erp.sales_service.dto.request.DeliveryRequest;
import com.erp.sales_service.dto.response.DeliveryResponse;

import java.util.List;

public interface DeliveryService {

    DeliveryResponse createDelivery(Long salesOrderId, DeliveryRequest request);

    DeliveryResponse getDeliveryById(Long id);

    List<DeliveryResponse> getDeliveriesForOrder(Long salesOrderId);
}