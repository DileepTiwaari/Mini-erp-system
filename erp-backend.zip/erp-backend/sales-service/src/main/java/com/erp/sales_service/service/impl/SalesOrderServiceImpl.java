package com.erp.sales_service.service.impl;

import com.erp.common.response.PageResponse;
import com.erp.sales_service.client.ProcurementServiceClient;
import com.erp.sales_service.dto.request.SalesOrderLineRequest;
import com.erp.sales_service.dto.request.SalesOrderRequest;
import com.erp.sales_service.dto.response.SalesOrderLineResponse;
import com.erp.sales_service.dto.response.SalesOrderResponse;
import com.erp.sales_service.entity.Customer;
import com.erp.sales_service.entity.SalesOrder;
import com.erp.sales_service.entity.SalesOrderLine;
import com.erp.sales_service.enums.SalesOrderStatus;
import com.erp.sales_service.exception.CustomerNotFoundException;
import com.erp.sales_service.exception.InvalidOrderStateException;
import com.erp.sales_service.exception.SalesOrderNotFoundException;
import com.erp.sales_service.repository.CustomerRepository;
import com.erp.sales_service.repository.SalesOrderRepository;
import com.erp.sales_service.service.interfaces.SalesOrderService;
import com.erp.sales_service.service.interfaces.StockCheckService;
import com.erp.sales_service.util.SalesUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class SalesOrderServiceImpl implements SalesOrderService {

    private final SalesOrderRepository salesOrderRepository;
    private final CustomerRepository customerRepository;
    private final StockCheckService stockCheckService;
    private final ProcurementServiceClient procurementServiceClient;
    private final SalesUtil salesUtil;

    @Override
    public SalesOrderResponse createSalesOrder(SalesOrderRequest request) {
        Customer customer = customerRepository.findById(request.getCustomerId())
                .orElseThrow(() -> new CustomerNotFoundException(
                        "Customer not found with id: " + request.getCustomerId()));

        SalesOrder salesOrder = SalesOrder.builder()
                .soNumber(salesUtil.generateSoNumber())
                .customer(customer)
                .status(SalesOrderStatus.DRAFT)
                .build();

        for (SalesOrderLineRequest lineRequest : request.getLines()) {
            SalesOrderLine line = SalesOrderLine.builder()
                    .productId(lineRequest.getProductId())
                    .productName(lineRequest.getProductName())
                    .quantity(lineRequest.getQuantity())
                    .deliveredQuantity(0)
                    .unitPrice(lineRequest.getUnitPrice())
                    .build();
            line.calculateLineTotal();
            salesOrder.addLine(line);
        }

        salesOrder.setTotalAmount(calculateTotal(salesOrder.getLines()));

        SalesOrder saved = salesOrderRepository.save(salesOrder);
        return mapToResponse(saved);
    }

    @Override
    public SalesOrderResponse updateSalesOrder(Long id, SalesOrderRequest request) {
        SalesOrder salesOrder = salesOrderRepository.findById(id)
                .orElseThrow(() -> new SalesOrderNotFoundException("Sales order not found with id: " + id));

        if (salesOrder.getStatus() != SalesOrderStatus.DRAFT) {
            throw new InvalidOrderStateException(
                    "Only DRAFT sales orders can be edited. Current status: " + salesOrder.getStatus());
        }

        Customer customer = customerRepository.findById(request.getCustomerId())
                .orElseThrow(() -> new CustomerNotFoundException(
                        "Customer not found with id: " + request.getCustomerId()));

        salesOrder.setCustomer(customer);
        salesOrder.getLines().clear();

        for (SalesOrderLineRequest lineRequest : request.getLines()) {
            SalesOrderLine line = SalesOrderLine.builder()
                    .productId(lineRequest.getProductId())
                    .productName(lineRequest.getProductName())
                    .quantity(lineRequest.getQuantity())
                    .deliveredQuantity(0)
                    .unitPrice(lineRequest.getUnitPrice())
                    .build();
            line.calculateLineTotal();
            salesOrder.addLine(line);
        }

        salesOrder.setTotalAmount(calculateTotal(salesOrder.getLines()));

        SalesOrder updated = salesOrderRepository.save(salesOrder);
        return mapToResponse(updated);
    }

    @Override
    @Transactional(readOnly = true)
    public SalesOrderResponse getSalesOrderById(Long id) {
        SalesOrder salesOrder = salesOrderRepository.findById(id)
                .orElseThrow(() -> new SalesOrderNotFoundException("Sales order not found with id: " + id));
        return mapToResponse(salesOrder);
    }

    @Override
    @Transactional(readOnly = true)
    public PageResponse<SalesOrderResponse> getAllSalesOrders(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<SalesOrder> soPage = salesOrderRepository.findAll(pageable);

        return PageResponse.<SalesOrderResponse>builder()
                .content(soPage.getContent().stream().map(this::mapToResponse).toList())
                .pageNumber(soPage.getNumber())
                .pageSize(soPage.getSize())
                .totalElements(soPage.getTotalElements())
                .totalPages(soPage.getTotalPages())
                .last(soPage.isLast())
                .build();
    }

    @Override
    public SalesOrderResponse confirmSalesOrder(Long id) {
        SalesOrder salesOrder = salesOrderRepository.findById(id)
                .orElseThrow(() -> new SalesOrderNotFoundException("Sales order not found with id: " + id));

        if (salesOrder.getStatus() != SalesOrderStatus.DRAFT) {
            throw new InvalidOrderStateException(
                    "Only DRAFT sales orders can be confirmed. Current status: " + salesOrder.getStatus());
        }

        for (SalesOrderLine line : salesOrder.getLines()) {
            int available = stockCheckService.getAvailableQuantity(line.getProductId());
            int required = line.getQuantity();

            if (available >= required) {
                stockCheckService.reserveStock(line.getProductId(), required, salesOrder.getSoNumber());
            } else {
                if (available > 0) {
                    stockCheckService.reserveStock(line.getProductId(), available, salesOrder.getSoNumber());
                }
                int shortage = required - available;
                procurementServiceClient.triggerProcurement(
                        ProcurementServiceClient.ProcurementTriggerRequest.builder()
                                .productId(line.getProductId())
                                .shortageQuantity(shortage)
                                .referenceType("SALES_ORDER")
                                .referenceNumber(salesOrder.getSoNumber())
                                .build()
                );
            }
        }

        salesOrder.setStatus(SalesOrderStatus.CONFIRMED);
        SalesOrder updated = salesOrderRepository.save(salesOrder);
        return mapToResponse(updated);
    }

    @Override
    public void cancelSalesOrder(Long id) {
        SalesOrder salesOrder = salesOrderRepository.findById(id)
                .orElseThrow(() -> new SalesOrderNotFoundException("Sales order not found with id: " + id));

        if (salesOrder.getStatus() == SalesOrderStatus.FULLY_DELIVERED) {
            throw new InvalidOrderStateException("Cannot cancel a fully delivered sales order");
        }

        if (salesOrder.getStatus() == SalesOrderStatus.CONFIRMED
                || salesOrder.getStatus() == SalesOrderStatus.PARTIALLY_DELIVERED) {
            for (SalesOrderLine line : salesOrder.getLines()) {
                int pendingReserved = line.getPendingQuantity();
                if (pendingReserved > 0) {
                    stockCheckService.releaseStock(line.getProductId(), pendingReserved, salesOrder.getSoNumber());
                }
            }
        }

        salesOrder.setStatus(SalesOrderStatus.CANCELLED);
        salesOrderRepository.save(salesOrder);
    }

    private BigDecimal calculateTotal(List<SalesOrderLine> lines) {
        return lines.stream()
                .map(SalesOrderLine::getLineTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private SalesOrderResponse mapToResponse(SalesOrder salesOrder) {
        List<SalesOrderLineResponse> lineResponses = salesOrder.getLines().stream()
                .map(line -> SalesOrderLineResponse.builder()
                        .id(line.getId())
                        .productId(line.getProductId())
                        .productName(line.getProductName())
                        .quantity(line.getQuantity())
                        .deliveredQuantity(line.getDeliveredQuantity())
                        .unitPrice(line.getUnitPrice())
                        .lineTotal(line.getLineTotal())
                        .build())
                .toList();

        return SalesOrderResponse.builder()
                .id(salesOrder.getId())
                .soNumber(salesOrder.getSoNumber())
                .customerId(salesOrder.getCustomer().getId())
                .customerName(salesOrder.getCustomer().getName())
                .status(salesOrder.getStatus())
                .orderDate(salesOrder.getOrderDate())
                .totalAmount(salesOrder.getTotalAmount())
                .lines(lineResponses)
                .createdAt(salesOrder.getCreatedAt())
                .build();
    }
}