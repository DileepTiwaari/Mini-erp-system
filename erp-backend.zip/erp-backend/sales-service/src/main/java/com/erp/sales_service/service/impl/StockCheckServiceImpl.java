package com.erp.sales_service.service.impl;

import com.erp.sales_service.client.InventoryServiceClient;
import com.erp.sales_service.service.interfaces.StockCheckService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class StockCheckServiceImpl implements StockCheckService {

    private final InventoryServiceClient inventoryServiceClient;

    @Override
    public int getAvailableQuantity(Long productId) {
        InventoryServiceClient.StockInfo stockInfo = inventoryServiceClient.getStock(productId);
        return stockInfo != null && stockInfo.getFreeToUseQuantity() != null
                ? stockInfo.getFreeToUseQuantity()
                : 0;
    }

    @Override
    public boolean isStockSufficient(Long productId, int requiredQuantity) {
        return getAvailableQuantity(productId) >= requiredQuantity;
    }

    @Override
    public void reserveStock(Long productId, int quantity, String referenceNumber) {
        inventoryServiceClient.reserveStock(
                InventoryServiceClient.StockChangeRequest.builder()
                        .productId(productId)
                        .quantity(quantity)
                        .referenceType("SALES_ORDER")
                        .referenceNumber(referenceNumber)
                        .build()
        );
    }

    @Override
    public void releaseStock(Long productId, int quantity, String referenceNumber) {
        inventoryServiceClient.releaseStock(
                InventoryServiceClient.StockChangeRequest.builder()
                        .productId(productId)
                        .quantity(quantity)
                        .referenceType("SALES_ORDER")
                        .referenceNumber(referenceNumber)
                        .build()
        );
    }
}