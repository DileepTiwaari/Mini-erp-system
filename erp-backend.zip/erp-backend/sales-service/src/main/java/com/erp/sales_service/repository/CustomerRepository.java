package com.erp.sales_service.repository;

import com.erp.sales_service.entity.Customer;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

    Page<Customer> findByActiveTrue(Pageable pageable);

    boolean existsByEmailIgnoreCase(String email);
}