package com.erp.sales_service.service.interfaces;

import com.erp.common.response.PageResponse;
import com.erp.sales_service.dto.request.CustomerRequest;
import com.erp.sales_service.dto.response.CustomerResponse;

public interface CustomerService {

    CustomerResponse createCustomer(CustomerRequest request);

    CustomerResponse updateCustomer(Long id, CustomerRequest request);

    CustomerResponse getCustomerById(Long id);

    PageResponse<CustomerResponse> getAllCustomers(int page, int size);

    void deleteCustomer(Long id);
}