package com.erp.sales_service.service.impl;

import com.erp.sales_service.client.InventoryServiceClient;
import com.erp.sales_service.dto.request.DeliveryRequest;
import com.erp.sales_service.dto.response.DeliveryItemResponse;
import com.erp.sales_service.dto.response.DeliveryResponse;
import com.erp.sales_service.entity.Delivery;
import com.erp.sales_service.entity.DeliveryItem;
import com.erp.sales_service.entity.SalesOrder;
import com.erp.sales_service.entity.SalesOrderLine;
import com.erp.sales_service.enums.DeliveryStatus;
import com.erp.sales_service.enums.SalesOrderStatus;
import com.erp.sales_service.exception.DeliveryNotFoundException;
import com.erp.sales_service.exception.InvalidOrderStateException;
import com.erp.sales_service.exception.SalesOrderNotFoundException;
import com.erp.sales_service.repository.DeliveryRepository;
import com.erp.sales_service.repository.SalesOrderRepository;
import com.erp.sales_service.service.interfaces.DeliveryService;
import com.erp.sales_service.util.SalesUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class DeliveryServiceImpl implements DeliveryService {

    private final DeliveryRepository deliveryRepository;
    private final SalesOrderRepository salesOrderRepository;
    private final InventoryServiceClient inventoryServiceClient;
    private final SalesUtil salesUtil;

    @Override
    public DeliveryResponse createDelivery(Long salesOrderId, DeliveryRequest request) {
        SalesOrder salesOrder = salesOrderRepository.findById(salesOrderId)
                .orElseThrow(() -> new SalesOrderNotFoundException(
                        "Sales order not found with id: " + salesOrderId));

        if (salesOrder.getStatus() != SalesOrderStatus.CONFIRMED
                && salesOrder.getStatus() != SalesOrderStatus.PARTIALLY_DELIVERED) {
            throw new InvalidOrderStateException(
                    "Goods can only be delivered for CONFIRMED or PARTIALLY_DELIVERED orders. Current status: "
                            + salesOrder.getStatus());
        }

        Map<Long, SalesOrderLine> lineMap = salesOrder.getLines().stream()
                .collect(Collectors.toMap(SalesOrderLine::getId, line -> line));

        Delivery delivery = Delivery.builder()
                .deliveryNumber(salesUtil.generateDeliveryNumber())
                .salesOrder(salesOrder)
                .build();

        for (DeliveryRequest.DeliverLineItem item : request.getItems()) {
            SalesOrderLine line = lineMap.get(item.getSalesOrderLineId());
            if (line == null) {
                throw new InvalidOrderStateException(
                        "Line item " + item.getSalesOrderLineId() + " does not belong to this sales order");
            }

            int newDeliveredQty = line.getDeliveredQuantity() + item.getDeliveredQuantity();
            if (newDeliveredQty > line.getQuantity()) {
                throw new InvalidOrderStateException(
                        "Delivered quantity exceeds ordered quantity for product: " + line.getProductName());
            }

            line.setDeliveredQuantity(newDeliveredQty);

            delivery.getItems().add(DeliveryItem.builder()
                    .salesOrderLineId(line.getId())
                    .productId(line.getProductId())
                    .deliveredQuantity(item.getDeliveredQuantity())
                    .build());

            inventoryServiceClient.decreaseStock(
                    InventoryServiceClient.StockChangeRequest.builder()
                            .productId(line.getProductId())
                            .quantity(item.getDeliveredQuantity())
                            .referenceType("SALES_ORDER")
                            .referenceNumber(salesOrder.getSoNumber())
                            .build()
            );
        }

        boolean fullyDelivered = salesOrder.getLines().stream()
                .allMatch(line -> line.getDeliveredQuantity().equals(line.getQuantity()));

        delivery.setStatus(fullyDelivered ? DeliveryStatus.COMPLETED : DeliveryStatus.PARTIAL);
        salesOrder.setStatus(fullyDelivered
                ? SalesOrderStatus.FULLY_DELIVERED
                : SalesOrderStatus.PARTIALLY_DELIVERED);

        salesOrderRepository.save(salesOrder);
        Delivery savedDelivery = deliveryRepository.save(delivery);

        return mapToResponse(savedDelivery);
    }

    @Override
    @Transactional(readOnly = true)
    public DeliveryResponse getDeliveryById(Long id) {
        Delivery delivery = deliveryRepository.findById(id)
                .orElseThrow(() -> new DeliveryNotFoundException("Delivery not found with id: " + id));
        return mapToResponse(delivery);
    }

    @Override
    @Transactional(readOnly = true)
    public List<DeliveryResponse> getDeliveriesForOrder(Long salesOrderId) {
        return deliveryRepository.findBySalesOrderId(salesOrderId).stream()
                .map(this::mapToResponse)
                .toList();
    }

    private DeliveryResponse mapToResponse(Delivery delivery) {
        List<DeliveryItemResponse> itemResponses = delivery.getItems().stream()
                .map(item -> DeliveryItemResponse.builder()
                        .salesOrderLineId(item.getSalesOrderLineId())
                        .productId(item.getProductId())
                        .deliveredQuantity(item.getDeliveredQuantity())
                        .build())
                .toList();

        return DeliveryResponse.builder()
                .id(delivery.getId())
                .deliveryNumber(delivery.getDeliveryNumber())
                .salesOrderId(delivery.getSalesOrder().getId())
                .status(delivery.getStatus())
                .deliveryDate(delivery.getDeliveryDate())
                .items(itemResponses)
                .createdAt(delivery.getCreatedAt())
                .build();
    }
}