package com.erp.sales_service.service.interfaces;

import com.erp.common.response.PageResponse;
import com.erp.sales_service.dto.request.SalesOrderRequest;
import com.erp.sales_service.dto.response.SalesOrderResponse;

public interface SalesOrderService {

    SalesOrderResponse createSalesOrder(SalesOrderRequest request);

    SalesOrderResponse updateSalesOrder(Long id, SalesOrderRequest request);

    SalesOrderResponse getSalesOrderById(Long id);

    PageResponse<SalesOrderResponse> getAllSalesOrders(int page, int size);

    SalesOrderResponse confirmSalesOrder(Long id);

    void cancelSalesOrder(Long id);
}