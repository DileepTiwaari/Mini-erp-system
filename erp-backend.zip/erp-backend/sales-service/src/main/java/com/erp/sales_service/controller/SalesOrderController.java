package com.erp.sales_service.controller;

import com.erp.common.response.ApiResponse;
import com.erp.common.response.PageResponse;
import com.erp.sales_service.dto.request.SalesOrderRequest;
import com.erp.sales_service.dto.response.SalesOrderResponse;
import com.erp.sales_service.service.interfaces.SalesOrderService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/sales-orders")
@RequiredArgsConstructor
public class SalesOrderController {

    private final SalesOrderService salesOrderService;

    @PostMapping
    public ResponseEntity<ApiResponse<SalesOrderResponse>> createSalesOrder(
            @Valid @RequestBody SalesOrderRequest request) {
        SalesOrderResponse response = salesOrderService.createSalesOrder(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Sales order created successfully", response));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<SalesOrderResponse>> updateSalesOrder(
            @PathVariable Long id, @Valid @RequestBody SalesOrderRequest request) {
        SalesOrderResponse response = salesOrderService.updateSalesOrder(id, request);
        return ResponseEntity.ok(ApiResponse.success("Sales order updated successfully", response));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<SalesOrderResponse>> getSalesOrderById(@PathVariable Long id) {
        SalesOrderResponse response = salesOrderService.getSalesOrderById(id);
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<PageResponse<SalesOrderResponse>>> getAllSalesOrders(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        PageResponse<SalesOrderResponse> response = salesOrderService.getAllSalesOrders(page, size);
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @PutMapping("/{id}/confirm")
    public ResponseEntity<ApiResponse<SalesOrderResponse>> confirmSalesOrder(@PathVariable Long id) {
        SalesOrderResponse response = salesOrderService.confirmSalesOrder(id);
        return ResponseEntity.ok(ApiResponse.success("Sales order confirmed", response));
    }

    @PutMapping("/{id}/cancel")
    public ResponseEntity<ApiResponse<Void>> cancelSalesOrder(@PathVariable Long id) {
        salesOrderService.cancelSalesOrder(id);
        return ResponseEntity.ok(ApiResponse.success("Sales order cancelled", null));
    }
}