package com.erp.sales_service.dto.response;

import com.erp.sales_service.enums.DeliveryStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DeliveryResponse {

    private Long id;
    private String deliveryNumber;
    private Long salesOrderId;
    private DeliveryStatus status;
    private LocalDate deliveryDate;
    private List<DeliveryItemResponse> items;
    private LocalDateTime createdAt;
}