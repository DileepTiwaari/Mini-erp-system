package com.erp.sales_service.util;

import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class SalesUtil {

    private final AtomicInteger soCounter = new AtomicInteger(1);
    private final AtomicInteger deliveryCounter = new AtomicInteger(1);

    public String generateSoNumber() {
        String datePart = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        int sequence = soCounter.getAndIncrement();
        return String.format("SO-%s-%04d", datePart, sequence);
    }

    public String generateDeliveryNumber() {
        String datePart = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        int sequence = deliveryCounter.getAndIncrement();
        return String.format("DEL-%s-%04d", datePart, sequence);
    }
}