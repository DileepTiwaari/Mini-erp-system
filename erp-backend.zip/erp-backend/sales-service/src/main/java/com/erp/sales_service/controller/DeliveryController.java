package com.erp.sales_service.controller;

import com.erp.common.response.ApiResponse;
import com.erp.sales_service.dto.request.DeliveryRequest;
import com.erp.sales_service.dto.response.DeliveryResponse;
import com.erp.sales_service.service.interfaces.DeliveryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/sales-orders/{salesOrderId}/deliveries")
@RequiredArgsConstructor
public class DeliveryController {

    private final DeliveryService deliveryService;

    @PostMapping
    public ResponseEntity<ApiResponse<DeliveryResponse>> createDelivery(
            @PathVariable Long salesOrderId,
            @Valid @RequestBody DeliveryRequest request) {
        DeliveryResponse response = deliveryService.createDelivery(salesOrderId, request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Delivery recorded and stock updated", response));
    }

    @GetMapping("/{deliveryId}")
    public ResponseEntity<ApiResponse<DeliveryResponse>> getDeliveryById(
            @PathVariable Long salesOrderId,
            @PathVariable Long deliveryId) {
        DeliveryResponse response = deliveryService.getDeliveryById(deliveryId);
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<DeliveryResponse>>> getDeliveriesForOrder(
            @PathVariable Long salesOrderId) {
        List<DeliveryResponse> response = deliveryService.getDeliveriesForOrder(salesOrderId);
        return ResponseEntity.ok(ApiResponse.success(response));
    }
}