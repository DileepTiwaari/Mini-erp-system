package com.erp.sales_service.client;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "procurement-service")
public interface ProcurementServiceClient {

    @PostMapping("/api/v1/procurement/trigger")
    void triggerProcurement(@RequestBody ProcurementTriggerRequest request);

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    class ProcurementTriggerRequest {
        private Long productId;
        private Integer shortageQuantity;
        private String referenceType;
        private String referenceNumber;
    }
}