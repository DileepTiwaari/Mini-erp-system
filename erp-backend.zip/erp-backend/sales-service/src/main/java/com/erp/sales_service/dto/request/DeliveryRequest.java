package com.erp.sales_service.dto.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DeliveryRequest {

    @NotEmpty(message = "At least one line item must be delivered")
    @Valid
    private List<DeliverLineItem> items;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class DeliverLineItem {

        @NotNull(message = "Sales order line ID is required")
        private Long salesOrderLineId;

        @Min(value = 1, message = "Delivered quantity must be at least 1")
        private Integer deliveredQuantity;
    }
}