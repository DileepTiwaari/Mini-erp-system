package com.erp.sales_service.service.interfaces;

public interface StockCheckService {

    int getAvailableQuantity(Long productId);

    boolean isStockSufficient(Long productId, int requiredQuantity);

    void reserveStock(Long productId, int quantity, String referenceNumber);

    void releaseStock(Long productId, int quantity, String referenceNumber);
}