package com.erp.sales_service.dto.response;

import com.erp.sales_service.enums.SalesOrderStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SalesOrderResponse {

    private Long id;
    private String soNumber;
    private Long customerId;
    private String customerName;
    private SalesOrderStatus status;
    private LocalDate orderDate;
    private BigDecimal totalAmount;
    private List<SalesOrderLineResponse> lines;
    private LocalDateTime createdAt;
}