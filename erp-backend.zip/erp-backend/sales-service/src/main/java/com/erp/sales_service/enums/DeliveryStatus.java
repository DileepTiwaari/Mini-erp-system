package com.erp.sales_service.enums;

public enum DeliveryStatus {
    PARTIAL,
    COMPLETED
}