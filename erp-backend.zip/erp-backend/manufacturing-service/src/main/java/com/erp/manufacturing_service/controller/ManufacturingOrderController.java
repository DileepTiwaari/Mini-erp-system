package com.erp.manufacturing_service.controller;

import com.erp.manufacturing_service.dto.request.ManufacturingOrderRequest;
import com.erp.manufacturing_service.dto.response.ManufacturingOrderResponse;
import com.erp.manufacturing_service.service.interfaces.ManufacturingOrderService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/manufacturing-orders")
public class ManufacturingOrderController {

    @Autowired
    private ManufacturingOrderService manufacturingOrderService;

    @PostMapping
    public ResponseEntity<?> createOrder(
            @Valid @RequestBody ManufacturingOrderRequest request) {
        ManufacturingOrderResponse response =
                manufacturingOrderService.createOrder(request);
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Manufacturing order created successfully",
                "data", response));
    }

    @GetMapping
    public ResponseEntity<?> getAllOrders() {
        List<ManufacturingOrderResponse> response =
                manufacturingOrderService.getAllOrders();
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Manufacturing orders fetched successfully",
                "data", response));
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getOrderById(@PathVariable Long id) {
        ManufacturingOrderResponse response =
                manufacturingOrderService.getOrderById(id);
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Manufacturing order fetched successfully",
                "data", response));
    }

    @PostMapping("/{id}/confirm")
    public ResponseEntity<?> confirmOrder(@PathVariable Long id) {
        ManufacturingOrderResponse response =
                manufacturingOrderService.confirmOrder(id);
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Manufacturing order confirmed successfully",
                "data", response));
    }

    @PostMapping("/{id}/start")
    public ResponseEntity<?> startOrder(@PathVariable Long id) {
        ManufacturingOrderResponse response =
                manufacturingOrderService.startOrder(id);
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Manufacturing order started successfully",
                "data", response));
    }

    @PostMapping("/{id}/complete")
    public ResponseEntity<?> completeOrder(@PathVariable Long id) {
        ManufacturingOrderResponse response =
                manufacturingOrderService.completeOrder(id);
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Manufacturing order completed successfully",
                "data", response));
    }

    @PostMapping("/{id}/cancel")
    public ResponseEntity<?> cancelOrder(@PathVariable Long id) {
        ManufacturingOrderResponse response =
                manufacturingOrderService.cancelOrder(id);
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Manufacturing order cancelled successfully",
                "data", response));
    }
}