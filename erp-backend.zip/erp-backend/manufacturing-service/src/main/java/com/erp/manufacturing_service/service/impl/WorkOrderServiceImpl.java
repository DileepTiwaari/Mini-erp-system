package com.erp.manufacturing_service.service.impl;

import com.erp.manufacturing_service.dto.request.WorkOrderUpdateRequest;
import com.erp.manufacturing_service.dto.response.WorkOrderResponse;
import com.erp.manufacturing_service.entity.WorkOrder;
import com.erp.manufacturing_service.enums.WorkOrderStatus;
import com.erp.manufacturing_service.exception.ManufacturingOrderNotFoundException;
import com.erp.manufacturing_service.repository.WorkOrderRepository;
import com.erp.manufacturing_service.service.interfaces.WorkOrderService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class WorkOrderServiceImpl implements WorkOrderService {

    @Autowired
    private WorkOrderRepository workOrderRepository;

    @Override
    public List<WorkOrderResponse> getWorkOrdersByManufacturingOrder(
            Long moId) {
        return workOrderRepository.findByManufacturingOrderId(moId)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public WorkOrderResponse updateWorkOrderStatus(Long id,
                                                   WorkOrderUpdateRequest request) {
        WorkOrder workOrder = workOrderRepository.findById(id)
                .orElseThrow(() -> new ManufacturingOrderNotFoundException(
                        "Work order not found with id: " + id));

        workOrder.setStatus(request.getStatus());

        if (request.getStatus() == WorkOrderStatus.IN_PROGRESS) {
            workOrder.setStartedAt(LocalDateTime.now());
        }
        if (request.getStatus() == WorkOrderStatus.COMPLETED) {
            workOrder.setCompletedAt(LocalDateTime.now());
        }

        workOrderRepository.save(workOrder);
        return mapToResponse(workOrder);
    }

    private WorkOrderResponse mapToResponse(WorkOrder workOrder) {
        return WorkOrderResponse.builder()
                .id(workOrder.getId())
                .manufacturingOrderId(
                        workOrder.getManufacturingOrder().getId())
                .operationName(workOrder.getOperationName())
                .workCenterId(workOrder.getWorkCenterId())
                .workCenterName(workOrder.getWorkCenterName())
                .durationMinutes(workOrder.getDurationMinutes())
                .sequenceOrder(workOrder.getSequenceOrder())
                .status(workOrder.getStatus())
                .startedAt(workOrder.getStartedAt())
                .completedAt(workOrder.getCompletedAt())
                .createdAt(workOrder.getCreatedAt())
                .build();
    }
}