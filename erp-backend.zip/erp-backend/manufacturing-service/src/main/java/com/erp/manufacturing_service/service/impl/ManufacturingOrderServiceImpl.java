package com.erp.manufacturing_service.service.impl;

import com.erp.manufacturing_service.client.BomServiceClient;
import com.erp.manufacturing_service.client.InventoryServiceClient;
import com.erp.manufacturing_service.dto.request.ManufacturingOrderRequest;
import com.erp.manufacturing_service.dto.response.ManufacturingOrderResponse;
import com.erp.manufacturing_service.dto.response.WorkOrderResponse;
import com.erp.manufacturing_service.entity.ManufacturingOrder;
import com.erp.manufacturing_service.entity.WorkOrder;
import com.erp.manufacturing_service.enums.ManufacturingOrderStatus;
import com.erp.manufacturing_service.enums.WorkOrderStatus;
import com.erp.manufacturing_service.exception.InvalidOrderStateException;
import com.erp.manufacturing_service.exception.ManufacturingOrderNotFoundException;
import com.erp.manufacturing_service.repository.ManufacturingOrderRepository;
import com.erp.manufacturing_service.repository.WorkOrderRepository;
import com.erp.manufacturing_service.service.interfaces.ManufacturingOrderService;
import com.erp.manufacturing_service.util.ManufacturingUtil;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ManufacturingOrderServiceImpl
        implements ManufacturingOrderService {

    @Autowired
    private ManufacturingOrderRepository manufacturingOrderRepository;

    @Autowired
    private WorkOrderRepository workOrderRepository;

    @Autowired
    private BomServiceClient bomServiceClient;

    @Autowired
    private InventoryServiceClient inventoryServiceClient;

    @Override
    @Transactional
    public ManufacturingOrderResponse createOrder(
            ManufacturingOrderRequest request) {

        ManufacturingOrder order = ManufacturingOrder.builder()
                .referenceNumber(ManufacturingUtil.generateReferenceNumber())
                .productId(request.getProductId())
                .productName(request.getProductName())
                .bomId(request.getBomId())
                .quantity(request.getQuantity())
                .status(ManufacturingOrderStatus.DRAFT)
                .assignee(request.getAssignee())
                .scheduledDate(request.getScheduledDate())
                .notes(request.getNotes())
                .build();

        manufacturingOrderRepository.save(order);

        // Fetch BOM and create work orders
        try {
            Map<String, Object> bomResponse =
                    bomServiceClient.getBomById(request.getBomId());
            if (bomResponse != null && bomResponse.containsKey("data")) {
                Map<String, Object> bomData =
                        (Map<String, Object>) bomResponse.get("data");
                List<Map<String, Object>> operations =
                        (List<Map<String, Object>>) bomData.get("operations");

                if (operations != null) {
                    List<WorkOrder> workOrders = new ArrayList<>();
                    for (Map<String, Object> op : operations) {
                        WorkOrder workOrder = WorkOrder.builder()
                                .manufacturingOrder(order)
                                .operationName(
                                        (String) op.get("operationName"))
                                .workCenterId(
                                        Long.valueOf(op.get("workCenterId")
                                                .toString()))
                                .workCenterName(
                                        op.getOrDefault("workCenterName",
                                                "").toString())
                                .durationMinutes(
                                        Integer.valueOf(
                                                op.get("durationMinutes")
                                                        .toString()))
                                .sequenceOrder(
                                        Integer.valueOf(
                                                op.get("sequenceOrder")
                                                        .toString()))
                                .status(WorkOrderStatus.PENDING)
                                .build();
                        workOrders.add(workOrder);
                    }
                    workOrderRepository.saveAll(workOrders);
                    order.setWorkOrders(workOrders);
                }
            }
        } catch (Exception e) {
            // BOM service unavailable - continue without work orders
        }

        return mapToResponse(order);
    }

    @Override
    public ManufacturingOrderResponse getOrderById(Long id) {
        ManufacturingOrder order = manufacturingOrderRepository.findById(id)
                .orElseThrow(() -> new ManufacturingOrderNotFoundException(
                        "Manufacturing order not found with id: " + id));
        return mapToResponse(order);
    }

    @Override
    public List<ManufacturingOrderResponse> getAllOrders() {
        return manufacturingOrderRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public ManufacturingOrderResponse confirmOrder(Long id) {
        ManufacturingOrder order = getOrder(id);
        if (order.getStatus() != ManufacturingOrderStatus.DRAFT) {
            throw new InvalidOrderStateException(
                    "Only DRAFT orders can be confirmed");
        }

        // Reserve components in inventory
        try {
            Map<String, Object> bomResponse =
                    bomServiceClient.getBomById(order.getBomId());
            if (bomResponse != null && bomResponse.containsKey("data")) {
                Map<String, Object> bomData =
                        (Map<String, Object>) bomResponse.get("data");
                List<Map<String, Object>> components =
                        (List<Map<String, Object>>) bomData.get("components");

                if (components != null) {
                    for (Map<String, Object> component : components) {
                        Map<String, Object> reserveRequest = new HashMap<>();
                        reserveRequest.put("productId",
                                component.get("componentProductId"));
                        double componentQty = Double.parseDouble(
                                component.get("quantity").toString());
                        double orderQty = order.getQuantity().doubleValue();
                        reserveRequest.put("quantity", componentQty * orderQty);
                        reserveRequest.put("referenceNumber",
                                order.getReferenceNumber());
                        inventoryServiceClient.reserveStock(reserveRequest);
                    }
                }
            }
        } catch (Exception e) {
            // Inventory service unavailable
        }

        order.setStatus(ManufacturingOrderStatus.CONFIRMED);
        manufacturingOrderRepository.save(order);
        return mapToResponse(order);
    }

    @Override
    @Transactional
    public ManufacturingOrderResponse startOrder(Long id) {
        ManufacturingOrder order = getOrder(id);
        if (order.getStatus() != ManufacturingOrderStatus.CONFIRMED) {
            throw new InvalidOrderStateException(
                    "Only CONFIRMED orders can be started");
        }
        order.setStatus(ManufacturingOrderStatus.IN_PROGRESS);
        manufacturingOrderRepository.save(order);
        return mapToResponse(order);
    }

    @Override
    @Transactional
    public ManufacturingOrderResponse completeOrder(Long id) {
        ManufacturingOrder order = getOrder(id);
        if (order.getStatus() != ManufacturingOrderStatus.IN_PROGRESS) {
            throw new InvalidOrderStateException(
                    "Only IN_PROGRESS orders can be completed");
        }

        // Move finished goods to stock
        try {
            Map<String, Object> moveRequest = new HashMap<>();
            moveRequest.put("productId", order.getProductId());
            moveRequest.put("quantity", order.getQuantity());
            moveRequest.put("movementType", "MANUFACTURING_IN");
            moveRequest.put("referenceNumber", order.getReferenceNumber());
            inventoryServiceClient.moveStock(moveRequest);
        } catch (Exception e) {
            // Inventory service unavailable
        }

        order.setStatus(ManufacturingOrderStatus.COMPLETED);
        order.setCompletedDate(LocalDate.now());
        manufacturingOrderRepository.save(order);
        return mapToResponse(order);
    }

    @Override
    @Transactional
    public ManufacturingOrderResponse cancelOrder(Long id) {
        ManufacturingOrder order = getOrder(id);
        if (order.getStatus() == ManufacturingOrderStatus.COMPLETED) {
            throw new InvalidOrderStateException(
                    "Completed orders cannot be cancelled");
        }

        // Release reserved stock if confirmed
        if (order.getStatus() == ManufacturingOrderStatus.CONFIRMED ||
                order.getStatus() == ManufacturingOrderStatus.IN_PROGRESS) {
            try {
                Map<String, Object> releaseRequest = new HashMap<>();
                releaseRequest.put("referenceNumber",
                        order.getReferenceNumber());
                inventoryServiceClient.releaseStock(releaseRequest);
            } catch (Exception e) {
                // Inventory service unavailable
            }
        }

        order.setStatus(ManufacturingOrderStatus.CANCELLED);
        manufacturingOrderRepository.save(order);
        return mapToResponse(order);
    }

    private ManufacturingOrder getOrder(Long id) {
        return manufacturingOrderRepository.findById(id)
                .orElseThrow(() -> new ManufacturingOrderNotFoundException(
                        "Manufacturing order not found with id: " + id));
    }

    private ManufacturingOrderResponse mapToResponse(
            ManufacturingOrder order) {
        List<WorkOrderResponse> workOrders = new ArrayList<>();
        if (order.getWorkOrders() != null) {
            workOrders = order.getWorkOrders().stream()
                    .map(wo -> WorkOrderResponse.builder()
                            .id(wo.getId())
                            .manufacturingOrderId(order.getId())
                            .operationName(wo.getOperationName())
                            .workCenterId(wo.getWorkCenterId())
                            .workCenterName(wo.getWorkCenterName())
                            .durationMinutes(wo.getDurationMinutes())
                            .sequenceOrder(wo.getSequenceOrder())
                            .status(wo.getStatus())
                            .startedAt(wo.getStartedAt())
                            .completedAt(wo.getCompletedAt())
                            .build())
                    .collect(Collectors.toList());
        }

        return ManufacturingOrderResponse.builder()
                .id(order.getId())
                .referenceNumber(order.getReferenceNumber())
                .productId(order.getProductId())
                .productName(order.getProductName())
                .bomId(order.getBomId())
                .quantity(order.getQuantity())
                .status(order.getStatus())
                .assignee(order.getAssignee())
                .scheduledDate(order.getScheduledDate())
                .completedDate(order.getCompletedDate())
                .notes(order.getNotes())
                .workOrders(workOrders)
                .createdAt(order.getCreatedAt())
                .build();
    }
}