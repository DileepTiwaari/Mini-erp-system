package com.erp.manufacturing_service.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class ManufacturingUtil {

    public static String generateReferenceNumber() {
        String timestamp = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        int random = new Random().nextInt(1000);
        return "MO-" + timestamp + "-" + String.format("%03d", random);
    }
}