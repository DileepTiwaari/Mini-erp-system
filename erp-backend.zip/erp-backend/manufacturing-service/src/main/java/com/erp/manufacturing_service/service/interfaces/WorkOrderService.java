package com.erp.manufacturing_service.service.interfaces;

import com.erp.manufacturing_service.dto.request.WorkOrderUpdateRequest;
import com.erp.manufacturing_service.dto.response.WorkOrderResponse;

import java.util.List;

public interface WorkOrderService {
    List<WorkOrderResponse> getWorkOrdersByManufacturingOrder(Long moId);
    WorkOrderResponse updateWorkOrderStatus(Long id,
                                            WorkOrderUpdateRequest request);
}