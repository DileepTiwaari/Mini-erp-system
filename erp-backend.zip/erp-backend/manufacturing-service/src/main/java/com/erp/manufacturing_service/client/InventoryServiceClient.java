package com.erp.manufacturing_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

@FeignClient(name = "inventory-service")
public interface InventoryServiceClient {

    @PostMapping("/api/stocks/reserve")
    Map<String, Object> reserveStock(@RequestBody Map<String, Object> request);

    @PostMapping("/api/stocks/release")
    Map<String, Object> releaseStock(@RequestBody Map<String, Object> request);

    @PostMapping("/api/stocks/move")
    Map<String, Object> moveStock(@RequestBody Map<String, Object> request);
}