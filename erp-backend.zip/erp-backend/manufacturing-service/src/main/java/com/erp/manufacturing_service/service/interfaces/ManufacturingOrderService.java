package com.erp.manufacturing_service.service.interfaces;

import com.erp.manufacturing_service.dto.request.ManufacturingOrderRequest;
import com.erp.manufacturing_service.dto.response.ManufacturingOrderResponse;

import java.util.List;

public interface ManufacturingOrderService {
    ManufacturingOrderResponse createOrder(ManufacturingOrderRequest request);
    ManufacturingOrderResponse getOrderById(Long id);
    List<ManufacturingOrderResponse> getAllOrders();
    ManufacturingOrderResponse confirmOrder(Long id);
    ManufacturingOrderResponse startOrder(Long id);
    ManufacturingOrderResponse completeOrder(Long id);
    ManufacturingOrderResponse cancelOrder(Long id);
}