package com.erp.manufacturing_service.exception;

public class ManufacturingOrderNotFoundException extends RuntimeException {
    public ManufacturingOrderNotFoundException(String message) {
        super(message);
    }
}