package com.erp.manufacturing_service.enums;

public enum ManufacturingOrderStatus {
    DRAFT,
    CONFIRMED,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
}