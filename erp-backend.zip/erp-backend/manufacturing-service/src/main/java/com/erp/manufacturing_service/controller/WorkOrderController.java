package com.erp.manufacturing_service.controller;

import com.erp.manufacturing_service.dto.request.WorkOrderUpdateRequest;
import com.erp.manufacturing_service.dto.response.WorkOrderResponse;
import com.erp.manufacturing_service.service.interfaces.WorkOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/work-orders")
public class WorkOrderController {

    @Autowired
    private WorkOrderService workOrderService;

    @GetMapping("/manufacturing-order/{moId}")
    public ResponseEntity<?> getWorkOrdersByMO(@PathVariable Long moId) {
        List<WorkOrderResponse> response =
                workOrderService.getWorkOrdersByManufacturingOrder(moId);
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Work orders fetched successfully",
                "data", response));
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateStatus(
            @PathVariable Long id,
            @RequestBody WorkOrderUpdateRequest request) {
        WorkOrderResponse response =
                workOrderService.updateWorkOrderStatus(id, request);
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Work order status updated successfully",
                "data", response));
    }
}