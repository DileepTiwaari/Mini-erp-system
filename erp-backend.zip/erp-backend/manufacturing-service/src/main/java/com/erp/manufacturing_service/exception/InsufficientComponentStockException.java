package com.erp.manufacturing_service.exception;

public class InsufficientComponentStockException extends RuntimeException {
    public InsufficientComponentStockException(String message) {
        super(message);
    }
}