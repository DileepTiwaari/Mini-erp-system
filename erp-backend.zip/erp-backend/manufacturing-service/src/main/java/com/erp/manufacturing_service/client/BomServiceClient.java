package com.erp.manufacturing_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Map;

@FeignClient(name = "bom-service")
public interface BomServiceClient {

    @GetMapping("/api/boms/{id}")
    Map<String, Object> getBomById(@PathVariable Long id);

    @GetMapping("/api/boms/product/{productId}")
    Map<String, Object> getBomByProductId(@PathVariable Long productId);
}