package com.erp.manufacturing_service.dto.response;

import com.erp.manufacturing_service.enums.ManufacturingOrderStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ManufacturingOrderResponse {
    private Long id;
    private String referenceNumber;
    private Long productId;
    private String productName;
    private Long bomId;
    private BigDecimal quantity;
    private ManufacturingOrderStatus status;
    private String assignee;
    private LocalDate scheduledDate;
    private LocalDate completedDate;
    private String notes;
    private List<WorkOrderResponse> workOrders;
    private LocalDateTime createdAt;
}