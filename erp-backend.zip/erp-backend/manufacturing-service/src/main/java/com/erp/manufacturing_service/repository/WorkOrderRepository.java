package com.erp.manufacturing_service.repository;

import com.erp.manufacturing_service.entity.WorkOrder;
import com.erp.manufacturing_service.enums.WorkOrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WorkOrderRepository extends JpaRepository<WorkOrder, Long> {
    List<WorkOrder> findByManufacturingOrderId(Long manufacturingOrderId);
    List<WorkOrder> findByStatus(WorkOrderStatus status);
}