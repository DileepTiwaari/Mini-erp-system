package com.erp.manufacturing_service.dto.request;

import com.erp.manufacturing_service.enums.WorkOrderStatus;
import lombok.Data;

@Data
public class WorkOrderUpdateRequest {
    private WorkOrderStatus status;
}