package com.erp.manufacturing_service.enums;

public enum WorkOrderStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
}