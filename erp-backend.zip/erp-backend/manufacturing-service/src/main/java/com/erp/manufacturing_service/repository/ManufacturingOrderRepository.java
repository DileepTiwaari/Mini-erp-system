package com.erp.manufacturing_service.repository;

import com.erp.manufacturing_service.entity.ManufacturingOrder;
import com.erp.manufacturing_service.enums.ManufacturingOrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ManufacturingOrderRepository
        extends JpaRepository<ManufacturingOrder, Long> {
    Optional<ManufacturingOrder> findByReferenceNumber(String referenceNumber);
    List<ManufacturingOrder> findByStatus(ManufacturingOrderStatus status);
    List<ManufacturingOrder> findByProductId(Long productId);
}