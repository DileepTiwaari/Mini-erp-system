package com.erp.manufacturing_service.dto.response;

import com.erp.manufacturing_service.enums.WorkOrderStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkOrderResponse {
    private Long id;
    private Long manufacturingOrderId;
    private String operationName;
    private Long workCenterId;
    private String workCenterName;
    private Integer durationMinutes;
    private Integer sequenceOrder;
    private WorkOrderStatus status;
    private LocalDateTime startedAt;
    private LocalDateTime completedAt;
    private LocalDateTime createdAt;
}