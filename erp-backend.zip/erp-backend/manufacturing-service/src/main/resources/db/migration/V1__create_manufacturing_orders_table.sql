CREATE TABLE IF NOT EXISTS manufacturing_orders (
                                                    id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                                    reference_number VARCHAR(50) NOT NULL UNIQUE,
    product_id BIGINT NOT NULL,
    product_name VARCHAR(100) NOT NULL,
    bom_id BIGINT NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    assignee VARCHAR(100),
    scheduled_date DATE,
    completed_date DATE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );