CREATE TABLE IF NOT EXISTS work_orders (
                                           id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                           manufacturing_order_id BIGINT NOT NULL,
                                           operation_name VARCHAR(100) NOT NULL,
    work_center_id BIGINT NOT NULL,
    work_center_name VARCHAR(100) NOT NULL,
    duration_minutes INT NOT NULL DEFAULT 0,
    sequence_order INT NOT NULL DEFAULT 1,
    status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    started_at TIMESTAMP NULL,
    completed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (manufacturing_order_id)
    REFERENCES manufacturing_orders(id) ON DELETE CASCADE
    );