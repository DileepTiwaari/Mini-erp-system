package com.erp.manufacturing_service.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ManufacturingOrderServiceTest {

    @Test
    void contextLoads() {
    }
}