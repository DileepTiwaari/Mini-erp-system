package com.erp.manufacturing_service.integration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ManufacturingIntegrationTest {

    @Test
    void contextLoads() {
    }
}