package com.erp.bom_service.repository;

import com.erp.bom_service.entity.BomOperation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BomOperationRepository extends JpaRepository<BomOperation, Long> {
    List<BomOperation> findByBomIdOrderBySequenceOrder(Long bomId);
    void deleteByBomId(Long bomId);
}