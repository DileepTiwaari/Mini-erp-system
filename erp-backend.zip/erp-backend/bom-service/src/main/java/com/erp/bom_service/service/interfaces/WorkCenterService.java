package com.erp.bom_service.service.interfaces;

import com.erp.bom_service.dto.request.WorkCenterRequest;
import com.erp.bom_service.dto.response.WorkCenterResponse;

import java.util.List;

public interface WorkCenterService {
    WorkCenterResponse createWorkCenter(WorkCenterRequest request);
    WorkCenterResponse getWorkCenterById(Long id);
    List<WorkCenterResponse> getAllWorkCenters();
    WorkCenterResponse updateWorkCenter(Long id, WorkCenterRequest request);
    void deleteWorkCenter(Long id);
}