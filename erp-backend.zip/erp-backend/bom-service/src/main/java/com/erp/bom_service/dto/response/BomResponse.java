package com.erp.bom_service.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BomResponse {
    private Long id;
    private Long productId;
    private String productName;
    private BigDecimal quantity;
    private Boolean isActive;
    private List<BomComponentResponse> components;
    private List<BomOperationResponse> operations;
    private LocalDateTime createdAt;
}