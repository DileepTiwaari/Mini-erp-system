package com.erp.bom_service.exception;

public class WorkCenterNotFoundException extends RuntimeException {
    public WorkCenterNotFoundException(String message) {
        super(message);
    }
}