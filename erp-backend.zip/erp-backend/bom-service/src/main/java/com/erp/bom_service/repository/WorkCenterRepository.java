package com.erp.bom_service.repository;

import com.erp.bom_service.entity.WorkCenter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WorkCenterRepository extends JpaRepository<WorkCenter, Long> {
    Boolean existsByName(String name);
    List<WorkCenter> findByIsActiveTrue();
}