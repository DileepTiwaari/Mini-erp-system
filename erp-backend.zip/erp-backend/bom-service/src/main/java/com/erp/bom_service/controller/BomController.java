package com.erp.bom_service.controller;

import com.erp.bom_service.dto.request.BomRequest;
import com.erp.bom_service.dto.response.BomResponse;
import com.erp.bom_service.service.interfaces.BomService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/boms")
public class BomController {

    @Autowired
    private BomService bomService;

    @PostMapping
    public ResponseEntity<?> createBom(
            @Valid @RequestBody BomRequest request) {
        BomResponse response = bomService.createBom(request);
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "BOM created successfully",
                "data", response));
    }

    @GetMapping
    public ResponseEntity<?> getAllBoms() {
        List<BomResponse> response = bomService.getAllBoms();
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "BOMs fetched successfully",
                "data", response));
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getBomById(@PathVariable Long id) {
        BomResponse response = bomService.getBomById(id);
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "BOM fetched successfully",
                "data", response));
    }

    @GetMapping("/product/{productId}")
    public ResponseEntity<?> getBomByProductId(
            @PathVariable Long productId) {
        BomResponse response = bomService.getBomByProductId(productId);
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "BOM fetched successfully",
                "data", response));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateBom(
            @PathVariable Long id,
            @Valid @RequestBody BomRequest request) {
        BomResponse response = bomService.updateBom(id, request);
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "BOM updated successfully",
                "data", response));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteBom(@PathVariable Long id) {
        bomService.deleteBom(id);
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "BOM deleted successfully"));
    }
}