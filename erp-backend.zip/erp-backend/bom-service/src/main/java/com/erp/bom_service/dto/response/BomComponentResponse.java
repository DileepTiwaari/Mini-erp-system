package com.erp.bom_service.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BomComponentResponse {
    private Long id;
    private Long componentProductId;
    private String componentProductName;
    private BigDecimal quantity;
}