package com.erp.bom_service.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class WorkCenterRequest {

    @NotBlank(message = "Work center name is required")
    private String name;

    private String description;

    private Integer capacity = 1;
}