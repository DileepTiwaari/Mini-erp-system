package com.erp.bom_service.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BomOperationResponse {
    private Long id;
    private Long workCenterId;
    private String operationName;
    private Integer durationMinutes;
    private Integer sequenceOrder;
}