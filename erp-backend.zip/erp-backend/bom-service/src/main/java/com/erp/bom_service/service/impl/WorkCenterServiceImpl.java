package com.erp.bom_service.service.impl;

import com.erp.bom_service.dto.request.WorkCenterRequest;
import com.erp.bom_service.dto.response.WorkCenterResponse;
import com.erp.bom_service.entity.WorkCenter;
import com.erp.bom_service.exception.WorkCenterNotFoundException;
import com.erp.bom_service.repository.WorkCenterRepository;
import com.erp.bom_service.service.interfaces.WorkCenterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class WorkCenterServiceImpl implements WorkCenterService {

    @Autowired
    private WorkCenterRepository workCenterRepository;

    @Override
    public WorkCenterResponse createWorkCenter(WorkCenterRequest request) {
        WorkCenter workCenter = WorkCenter.builder()
                .name(request.getName())
                .description(request.getDescription())
                .capacity(request.getCapacity())
                .isActive(true)
                .build();
        workCenterRepository.save(workCenter);
        return mapToResponse(workCenter);
    }

    @Override
    public WorkCenterResponse getWorkCenterById(Long id) {
        WorkCenter workCenter = workCenterRepository.findById(id)
                .orElseThrow(() -> new WorkCenterNotFoundException(
                        "Work center not found with id: " + id));
        return mapToResponse(workCenter);
    }

    @Override
    public List<WorkCenterResponse> getAllWorkCenters() {
        return workCenterRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public WorkCenterResponse updateWorkCenter(Long id,
                                               WorkCenterRequest request) {
        WorkCenter workCenter = workCenterRepository.findById(id)
                .orElseThrow(() -> new WorkCenterNotFoundException(
                        "Work center not found with id: " + id));
        if (request.getName() != null) workCenter.setName(request.getName());
        if (request.getDescription() != null)
            workCenter.setDescription(request.getDescription());
        if (request.getCapacity() != null)
            workCenter.setCapacity(request.getCapacity());
        workCenterRepository.save(workCenter);
        return mapToResponse(workCenter);
    }

    @Override
    public void deleteWorkCenter(Long id) {
        WorkCenter workCenter = workCenterRepository.findById(id)
                .orElseThrow(() -> new WorkCenterNotFoundException(
                        "Work center not found with id: " + id));
        workCenterRepository.delete(workCenter);
    }

    private WorkCenterResponse mapToResponse(WorkCenter workCenter) {
        return WorkCenterResponse.builder()
                .id(workCenter.getId())
                .name(workCenter.getName())
                .description(workCenter.getDescription())
                .capacity(workCenter.getCapacity())
                .isActive(workCenter.getIsActive())
                .createdAt(workCenter.getCreatedAt())
                .build();
    }
}