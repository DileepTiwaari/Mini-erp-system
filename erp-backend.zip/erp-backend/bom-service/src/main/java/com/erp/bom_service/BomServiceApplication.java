package com.erp.bom_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class BomServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BomServiceApplication.class, args);
	}
}