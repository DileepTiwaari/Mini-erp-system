package com.erp.bom_service.util;

import java.math.BigDecimal;

public class BomUtil {

    public static BigDecimal calculateRequiredQty(
            BigDecimal componentQty, BigDecimal manufacturingQty) {
        if (componentQty == null) return BigDecimal.ZERO;
        if (manufacturingQty == null) return BigDecimal.ZERO;
        return componentQty.multiply(manufacturingQty);
    }
}