package com.erp.bom_service.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkCenterResponse {
    private Long id;
    private String name;
    private String description;
    private Integer capacity;
    private Boolean isActive;
    private LocalDateTime createdAt;
}