package com.erp.bom_service.exception;

public class BomNotFoundException extends RuntimeException {
    public BomNotFoundException(String message) {
        super(message);
    }
}