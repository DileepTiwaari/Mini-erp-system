package com.erp.bom_service.controller;

import com.erp.bom_service.dto.request.WorkCenterRequest;
import com.erp.bom_service.dto.response.WorkCenterResponse;
import com.erp.bom_service.service.interfaces.WorkCenterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/work-centers")
public class WorkCenterController {

    @Autowired
    private WorkCenterService workCenterService;

    @PostMapping
    public ResponseEntity<?> createWorkCenter(
            @Valid @RequestBody WorkCenterRequest request) {
        WorkCenterResponse response =
                workCenterService.createWorkCenter(request);
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Work center created successfully",
                "data", response));
    }

    @GetMapping
    public ResponseEntity<?> getAllWorkCenters() {
        List<WorkCenterResponse> response =
                workCenterService.getAllWorkCenters();
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Work centers fetched successfully",
                "data", response));
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getWorkCenterById(@PathVariable Long id) {
        WorkCenterResponse response =
                workCenterService.getWorkCenterById(id);
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Work center fetched successfully",
                "data", response));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateWorkCenter(
            @PathVariable Long id,
            @Valid @RequestBody WorkCenterRequest request) {
        WorkCenterResponse response =
                workCenterService.updateWorkCenter(id, request);
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Work center updated successfully",
                "data", response));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteWorkCenter(@PathVariable Long id) {
        workCenterService.deleteWorkCenter(id);
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Work center deleted successfully"));
    }
}