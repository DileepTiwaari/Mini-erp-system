package com.erp.bom_service.repository;

import com.erp.bom_service.entity.Bom;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BomRepository extends JpaRepository<Bom, Long> {
    Optional<Bom> findByProductId(Long productId);
    List<Bom> findByIsActiveTrue();
    Boolean existsByProductId(Long productId);
}