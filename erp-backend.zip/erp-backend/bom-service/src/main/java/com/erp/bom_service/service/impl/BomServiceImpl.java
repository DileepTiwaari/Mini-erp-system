package com.erp.bom_service.service.impl;

import com.erp.bom_service.dto.request.BomRequest;
import com.erp.bom_service.dto.response.BomComponentResponse;
import com.erp.bom_service.dto.response.BomOperationResponse;
import com.erp.bom_service.dto.response.BomResponse;
import com.erp.bom_service.entity.Bom;
import com.erp.bom_service.entity.BomComponent;
import com.erp.bom_service.entity.BomOperation;
import com.erp.bom_service.exception.BomNotFoundException;
import com.erp.bom_service.repository.BomComponentRepository;
import com.erp.bom_service.repository.BomOperationRepository;
import com.erp.bom_service.repository.BomRepository;
import com.erp.bom_service.service.interfaces.BomService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BomServiceImpl implements BomService {

    @Autowired
    private BomRepository bomRepository;

    @Autowired
    private BomComponentRepository bomComponentRepository;

    @Autowired
    private BomOperationRepository bomOperationRepository;

    @Override
    @Transactional
    public BomResponse createBom(BomRequest request) {
        Bom bom = Bom.builder()
                .productId(request.getProductId())
                .productName(request.getProductName())
                .quantity(request.getQuantity())
                .isActive(true)
                .build();
        bomRepository.save(bom);

        if (request.getComponents() != null) {
            List<BomComponent> components = request.getComponents()
                    .stream()
                    .map(c -> BomComponent.builder()
                            .bom(bom)
                            .componentProductId(c.getComponentProductId())
                            .componentProductName(c.getComponentProductName())
                            .quantity(c.getQuantity())
                            .build())
                    .collect(Collectors.toList());
            bomComponentRepository.saveAll(components);
            bom.setComponents(components);
        }

        if (request.getOperations() != null) {
            List<BomOperation> operations = request.getOperations()
                    .stream()
                    .map(o -> BomOperation.builder()
                            .bom(bom)
                            .workCenterId(o.getWorkCenterId())
                            .operationName(o.getOperationName())
                            .durationMinutes(o.getDurationMinutes())
                            .sequenceOrder(o.getSequenceOrder())
                            .build())
                    .collect(Collectors.toList());
            bomOperationRepository.saveAll(operations);
            bom.setOperations(operations);
        }

        return mapToResponse(bom);
    }

    @Override
    public BomResponse getBomById(Long id) {
        Bom bom = bomRepository.findById(id)
                .orElseThrow(() -> new BomNotFoundException(
                        "BOM not found with id: " + id));
        return mapToResponse(bom);
    }

    @Override
    public BomResponse getBomByProductId(Long productId) {
        Bom bom = bomRepository.findByProductId(productId)
                .orElseThrow(() -> new BomNotFoundException(
                        "BOM not found for product id: " + productId));
        return mapToResponse(bom);
    }

    @Override
    public List<BomResponse> getAllBoms() {
        return bomRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public BomResponse updateBom(Long id, BomRequest request) {
        Bom bom = bomRepository.findById(id)
                .orElseThrow(() -> new BomNotFoundException(
                        "BOM not found with id: " + id));

        if (request.getProductName() != null)
            bom.setProductName(request.getProductName());
        if (request.getQuantity() != null)
            bom.setQuantity(request.getQuantity());

        bomComponentRepository.deleteByBomId(id);
        bomOperationRepository.deleteByBomId(id);

        if (request.getComponents() != null) {
            List<BomComponent> components = request.getComponents()
                    .stream()
                    .map(c -> BomComponent.builder()
                            .bom(bom)
                            .componentProductId(c.getComponentProductId())
                            .componentProductName(c.getComponentProductName())
                            .quantity(c.getQuantity())
                            .build())
                    .collect(Collectors.toList());
            bomComponentRepository.saveAll(components);
        }

        if (request.getOperations() != null) {
            List<BomOperation> operations = request.getOperations()
                    .stream()
                    .map(o -> BomOperation.builder()
                            .bom(bom)
                            .workCenterId(o.getWorkCenterId())
                            .operationName(o.getOperationName())
                            .durationMinutes(o.getDurationMinutes())
                            .sequenceOrder(o.getSequenceOrder())
                            .build())
                    .collect(Collectors.toList());
            bomOperationRepository.saveAll(operations);
        }

        bomRepository.save(bom);
        return mapToResponse(bom);
    }

    @Override
    @Transactional
    public void deleteBom(Long id) {
        Bom bom = bomRepository.findById(id)
                .orElseThrow(() -> new BomNotFoundException(
                        "BOM not found with id: " + id));
        bomRepository.delete(bom);
    }

    private BomResponse mapToResponse(Bom bom) {
        List<BomComponentResponse> components = new ArrayList<>();
        List<BomOperationResponse> operations = new ArrayList<>();

        if (bom.getComponents() != null) {
            components = bom.getComponents().stream()
                    .map(c -> BomComponentResponse.builder()
                            .id(c.getId())
                            .componentProductId(c.getComponentProductId())
                            .componentProductName(c.getComponentProductName())
                            .quantity(c.getQuantity())
                            .build())
                    .collect(Collectors.toList());
        }

        if (bom.getOperations() != null) {
            operations = bom.getOperations().stream()
                    .map(o -> BomOperationResponse.builder()
                            .id(o.getId())
                            .workCenterId(o.getWorkCenterId())
                            .operationName(o.getOperationName())
                            .durationMinutes(o.getDurationMinutes())
                            .sequenceOrder(o.getSequenceOrder())
                            .build())
                    .collect(Collectors.toList());
        }

        return BomResponse.builder()
                .id(bom.getId())
                .productId(bom.getProductId())
                .productName(bom.getProductName())
                .quantity(bom.getQuantity())
                .isActive(bom.getIsActive())
                .components(components)
                .operations(operations)
                .createdAt(bom.getCreatedAt())
                .build();
    }
}