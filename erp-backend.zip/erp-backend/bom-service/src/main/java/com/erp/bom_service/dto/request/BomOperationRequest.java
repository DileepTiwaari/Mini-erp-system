package com.erp.bom_service.dto.request;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class BomOperationRequest {

    @NotNull(message = "Work center ID is required")
    private Long workCenterId;

    @NotBlank(message = "Operation name is required")
    private String operationName;

    @Min(value = 1, message = "Duration must be at least 1 minute")
    private Integer durationMinutes;

    private Integer sequenceOrder = 1;
}