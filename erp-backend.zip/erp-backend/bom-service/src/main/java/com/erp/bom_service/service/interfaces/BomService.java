package com.erp.bom_service.service.interfaces;

import com.erp.bom_service.dto.request.BomRequest;
import com.erp.bom_service.dto.response.BomResponse;

import java.util.List;

public interface BomService {
    BomResponse createBom(BomRequest request);
    BomResponse getBomById(Long id);
    BomResponse getBomByProductId(Long productId);
    List<BomResponse> getAllBoms();
    BomResponse updateBom(Long id, BomRequest request);
    void deleteBom(Long id);
}