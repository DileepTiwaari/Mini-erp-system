CREATE TABLE IF NOT EXISTS boms (
                                    id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                    product_id BIGINT NOT NULL,
                                    product_name VARCHAR(100) NOT NULL,
    quantity DECIMAL(10,2) NOT NULL DEFAULT 1.00,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );