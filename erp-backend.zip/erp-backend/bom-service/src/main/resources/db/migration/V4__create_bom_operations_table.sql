CREATE TABLE IF NOT EXISTS bom_operations (
                                              id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                              bom_id BIGINT NOT NULL,
                                              work_center_id BIGINT NOT NULL,
                                              operation_name VARCHAR(100) NOT NULL,
    duration_minutes INT NOT NULL DEFAULT 0,
    sequence_order INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bom_id) REFERENCES boms(id) ON DELETE CASCADE,
    FOREIGN KEY (work_center_id) REFERENCES work_centers(id)
    );