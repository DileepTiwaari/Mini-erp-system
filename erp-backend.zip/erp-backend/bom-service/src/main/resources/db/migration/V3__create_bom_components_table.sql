CREATE TABLE IF NOT EXISTS bom_components (
                                              id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                              bom_id BIGINT NOT NULL,
                                              component_product_id BIGINT NOT NULL,
                                              component_product_name VARCHAR(100) NOT NULL,
    quantity DECIMAL(10,2) NOT NULL DEFAULT 1.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bom_id) REFERENCES boms(id) ON DELETE CASCADE
    );