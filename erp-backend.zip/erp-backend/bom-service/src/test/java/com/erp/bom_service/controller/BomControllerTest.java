package com.erp.bom_service.controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class BomControllerTest {

    @Test
    void contextLoads() {
    }
}