package com.erp.bom_service.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class BomServiceTest {

    @Test
    void contextLoads() {
    }
}