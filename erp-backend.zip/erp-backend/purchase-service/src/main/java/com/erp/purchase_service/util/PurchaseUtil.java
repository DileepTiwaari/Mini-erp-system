package com.erp.purchase_service.util;

import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class PurchaseUtil {

    private final AtomicInteger counter = new AtomicInteger(1);

    public String generatePoNumber() {
        String datePart = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        int sequence = counter.getAndIncrement();
        return String.format("PO-%s-%04d", datePart, sequence);
    }
}