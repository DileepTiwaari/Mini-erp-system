package com.erp.purchase_service.dto.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PurchaseOrderRequest {

    @NotNull(message = "Vendor ID is required")
    private Long vendorId;

    private LocalDate expectedDeliveryDate;

    @NotEmpty(message = "At least one purchase order line is required")
    @Valid
    private List<PurchaseOrderLineRequest> lines;
}