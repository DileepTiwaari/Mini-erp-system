package com.erp.purchase_service.service.impl;

import com.erp.common.response.PageResponse;
import com.erp.purchase_service.client.InventoryServiceClient;
import com.erp.purchase_service.dto.request.PurchaseOrderLineRequest;
import com.erp.purchase_service.dto.request.PurchaseOrderRequest;
import com.erp.purchase_service.dto.request.ReceiveGoodsRequest;
import com.erp.purchase_service.dto.response.PurchaseOrderLineResponse;
import com.erp.purchase_service.dto.response.PurchaseOrderResponse;
import com.erp.purchase_service.entity.PurchaseOrder;
import com.erp.purchase_service.entity.PurchaseOrderLine;
import com.erp.purchase_service.entity.Vendor;
import com.erp.purchase_service.enums.PurchaseOrderStatus;
import com.erp.purchase_service.exception.InvalidOrderStateException;
import com.erp.purchase_service.exception.PurchaseOrderNotFoundException;
import com.erp.purchase_service.exception.VendorNotFoundException;
import com.erp.purchase_service.repository.PurchaseOrderRepository;
import com.erp.purchase_service.repository.VendorRepository;
import com.erp.purchase_service.service.interfaces.PurchaseOrderService;
import com.erp.purchase_service.util.PurchaseUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class PurchaseOrderServiceImpl implements PurchaseOrderService {

    private final PurchaseOrderRepository purchaseOrderRepository;
    private final VendorRepository vendorRepository;
    private final InventoryServiceClient inventoryServiceClient;
    private final PurchaseUtil purchaseUtil;

    @Override
    public PurchaseOrderResponse createPurchaseOrder(PurchaseOrderRequest request) {
        Vendor vendor = vendorRepository.findById(request.getVendorId())
                .orElseThrow(() -> new VendorNotFoundException(
                        "Vendor not found with id: " + request.getVendorId()));

        PurchaseOrder purchaseOrder = PurchaseOrder.builder()
                .poNumber(purchaseUtil.generatePoNumber())
                .vendor(vendor)
                .status(PurchaseOrderStatus.DRAFT)
                .expectedDeliveryDate(request.getExpectedDeliveryDate())
                .build();

        for (PurchaseOrderLineRequest lineRequest : request.getLines()) {
            PurchaseOrderLine line = PurchaseOrderLine.builder()
                    .productId(lineRequest.getProductId())
                    .productName(lineRequest.getProductName())
                    .quantity(lineRequest.getQuantity())
                    .receivedQuantity(0)
                    .unitPrice(lineRequest.getUnitPrice())
                    .build();
            line.calculateLineTotal();
            purchaseOrder.addLine(line);
        }

        purchaseOrder.setTotalAmount(calculateTotal(purchaseOrder.getLines()));

        PurchaseOrder saved = purchaseOrderRepository.save(purchaseOrder);
        return mapToResponse(saved);
    }

    @Override
    public PurchaseOrderResponse updatePurchaseOrder(Long id, PurchaseOrderRequest request) {
        PurchaseOrder purchaseOrder = purchaseOrderRepository.findById(id)
                .orElseThrow(() -> new PurchaseOrderNotFoundException("Purchase order not found with id: " + id));

        if (purchaseOrder.getStatus() != PurchaseOrderStatus.DRAFT) {
            throw new InvalidOrderStateException(
                    "Only DRAFT purchase orders can be edited. Current status: " + purchaseOrder.getStatus());
        }

        Vendor vendor = vendorRepository.findById(request.getVendorId())
                .orElseThrow(() -> new VendorNotFoundException(
                        "Vendor not found with id: " + request.getVendorId()));

        purchaseOrder.setVendor(vendor);
        purchaseOrder.setExpectedDeliveryDate(request.getExpectedDeliveryDate());

        purchaseOrder.getLines().clear();
        for (PurchaseOrderLineRequest lineRequest : request.getLines()) {
            PurchaseOrderLine line = PurchaseOrderLine.builder()
                    .productId(lineRequest.getProductId())
                    .productName(lineRequest.getProductName())
                    .quantity(lineRequest.getQuantity())
                    .receivedQuantity(0)
                    .unitPrice(lineRequest.getUnitPrice())
                    .build();
            line.calculateLineTotal();
            purchaseOrder.addLine(line);
        }

        purchaseOrder.setTotalAmount(calculateTotal(purchaseOrder.getLines()));

        PurchaseOrder updated = purchaseOrderRepository.save(purchaseOrder);
        return mapToResponse(updated);
    }

    @Override
    @Transactional(readOnly = true)
    public PurchaseOrderResponse getPurchaseOrderById(Long id) {
        PurchaseOrder purchaseOrder = purchaseOrderRepository.findById(id)
                .orElseThrow(() -> new PurchaseOrderNotFoundException("Purchase order not found with id: " + id));
        return mapToResponse(purchaseOrder);
    }

    @Override
    @Transactional(readOnly = true)
    public PageResponse<PurchaseOrderResponse> getAllPurchaseOrders(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<PurchaseOrder> poPage = purchaseOrderRepository.findAll(pageable);

        return PageResponse.<PurchaseOrderResponse>builder()
                .content(poPage.getContent().stream().map(this::mapToResponse).toList())
                .pageNumber(poPage.getNumber())
                .pageSize(poPage.getSize())
                .totalElements(poPage.getTotalElements())
                .totalPages(poPage.getTotalPages())
                .last(poPage.isLast())
                .build();
    }

    @Override
    public PurchaseOrderResponse confirmPurchaseOrder(Long id) {
        PurchaseOrder purchaseOrder = purchaseOrderRepository.findById(id)
                .orElseThrow(() -> new PurchaseOrderNotFoundException("Purchase order not found with id: " + id));

        if (purchaseOrder.getStatus() != PurchaseOrderStatus.DRAFT) {
            throw new InvalidOrderStateException(
                    "Only DRAFT purchase orders can be confirmed. Current status: " + purchaseOrder.getStatus());
        }

        purchaseOrder.setStatus(PurchaseOrderStatus.CONFIRMED);
        PurchaseOrder updated = purchaseOrderRepository.save(purchaseOrder);
        return mapToResponse(updated);
    }

    @Override
    public PurchaseOrderResponse receiveGoods(Long id, ReceiveGoodsRequest request) {
        PurchaseOrder purchaseOrder = purchaseOrderRepository.findById(id)
                .orElseThrow(() -> new PurchaseOrderNotFoundException("Purchase order not found with id: " + id));

        if (purchaseOrder.getStatus() != PurchaseOrderStatus.CONFIRMED
                && purchaseOrder.getStatus() != PurchaseOrderStatus.PARTIALLY_RECEIVED) {
            throw new InvalidOrderStateException(
                    "Goods can only be received for CONFIRMED or PARTIALLY_RECEIVED orders. Current status: "
                            + purchaseOrder.getStatus());
        }

        Map<Long, PurchaseOrderLine> lineMap = purchaseOrder.getLines().stream()
                .collect(Collectors.toMap(PurchaseOrderLine::getId, line -> line));

        for (ReceiveGoodsRequest.ReceiveLineItem item : request.getItems()) {
            PurchaseOrderLine line = lineMap.get(item.getLineId());
            if (line == null) {
                throw new InvalidOrderStateException(
                        "Line item " + item.getLineId() + " does not belong to this purchase order");
            }

            int newReceivedQty = line.getReceivedQuantity() + item.getReceivedQuantity();
            if (newReceivedQty > line.getQuantity()) {
                throw new InvalidOrderStateException(
                        "Received quantity exceeds ordered quantity for product: " + line.getProductName());
            }

            line.setReceivedQuantity(newReceivedQty);

            inventoryServiceClient.increaseStock(
                    InventoryServiceClient.StockIncreaseRequest.builder()
                            .productId(line.getProductId())
                            .quantity(item.getReceivedQuantity())
                            .referenceType("PURCHASE_ORDER")
                            .referenceNumber(purchaseOrder.getPoNumber())
                            .build()
            );
        }

        boolean fullyReceived = purchaseOrder.getLines().stream()
                .allMatch(line -> line.getReceivedQuantity().equals(line.getQuantity()));

        purchaseOrder.setStatus(fullyReceived
                ? PurchaseOrderStatus.FULLY_RECEIVED
                : PurchaseOrderStatus.PARTIALLY_RECEIVED);

        PurchaseOrder updated = purchaseOrderRepository.save(purchaseOrder);
        return mapToResponse(updated);
    }

    @Override
    public void cancelPurchaseOrder(Long id) {
        PurchaseOrder purchaseOrder = purchaseOrderRepository.findById(id)
                .orElseThrow(() -> new PurchaseOrderNotFoundException("Purchase order not found with id: " + id));

        if (purchaseOrder.getStatus() == PurchaseOrderStatus.FULLY_RECEIVED) {
            throw new InvalidOrderStateException("Cannot cancel a fully received purchase order");
        }

        purchaseOrder.setStatus(PurchaseOrderStatus.CANCELLED);
        purchaseOrderRepository.save(purchaseOrder);
    }

    private BigDecimal calculateTotal(List<PurchaseOrderLine> lines) {
        return lines.stream()
                .map(PurchaseOrderLine::getLineTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private PurchaseOrderResponse mapToResponse(PurchaseOrder purchaseOrder) {
        List<PurchaseOrderLineResponse> lineResponses = purchaseOrder.getLines().stream()
                .map(line -> PurchaseOrderLineResponse.builder()
                        .id(line.getId())
                        .productId(line.getProductId())
                        .productName(line.getProductName())
                        .quantity(line.getQuantity())
                        .receivedQuantity(line.getReceivedQuantity())
                        .unitPrice(line.getUnitPrice())
                        .lineTotal(line.getLineTotal())
                        .build())
                .toList();

        return PurchaseOrderResponse.builder()
                .id(purchaseOrder.getId())
                .poNumber(purchaseOrder.getPoNumber())
                .vendorId(purchaseOrder.getVendor().getId())
                .vendorName(purchaseOrder.getVendor().getName())
                .status(purchaseOrder.getStatus())
                .orderDate(purchaseOrder.getOrderDate())
                .expectedDeliveryDate(purchaseOrder.getExpectedDeliveryDate())
                .totalAmount(purchaseOrder.getTotalAmount())
                .lines(lineResponses)
                .createdAt(purchaseOrder.getCreatedAt())
                .build();
    }
}