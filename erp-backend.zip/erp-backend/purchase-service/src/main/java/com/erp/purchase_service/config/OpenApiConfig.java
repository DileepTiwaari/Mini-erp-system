package com.erp.purchase_service.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI purchaseServiceOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Purchase Service API")
                        .description("Mini ERP - Purchase Order & Vendor Management")
                        .version("v1.0.0"));
    }
}