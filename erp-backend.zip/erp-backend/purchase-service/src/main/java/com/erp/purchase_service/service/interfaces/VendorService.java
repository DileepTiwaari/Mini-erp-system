package com.erp.purchase_service.service.interfaces;

import com.erp.common.response.PageResponse;
import com.erp.purchase_service.dto.request.VendorRequest;
import com.erp.purchase_service.dto.response.VendorResponse;

public interface VendorService {

    VendorResponse createVendor(VendorRequest request);

    VendorResponse updateVendor(Long id, VendorRequest request);

    VendorResponse getVendorById(Long id);

    PageResponse<VendorResponse> getAllVendors(int page, int size);

    void deleteVendor(Long id);
}