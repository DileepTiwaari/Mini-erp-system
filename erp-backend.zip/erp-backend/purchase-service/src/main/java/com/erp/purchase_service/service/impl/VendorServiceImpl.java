package com.erp.purchase_service.service.impl;

import com.erp.common.response.PageResponse;
import com.erp.purchase_service.dto.request.VendorRequest;
import com.erp.purchase_service.dto.response.VendorResponse;
import com.erp.purchase_service.entity.Vendor;
import com.erp.purchase_service.exception.VendorNotFoundException;
import com.erp.purchase_service.repository.VendorRepository;
import com.erp.purchase_service.service.interfaces.VendorService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class VendorServiceImpl implements VendorService {

    private final VendorRepository vendorRepository;

    @Override
    public VendorResponse createVendor(VendorRequest request) {
        Vendor vendor = Vendor.builder()
                .name(request.getName())
                .contactPerson(request.getContactPerson())
                .email(request.getEmail())
                .phone(request.getPhone())
                .address(request.getAddress())
                .gstNumber(request.getGstNumber())
                .active(true)
                .build();

        Vendor saved = vendorRepository.save(vendor);
        return mapToResponse(saved);
    }

    @Override
    public VendorResponse updateVendor(Long id, VendorRequest request) {
        Vendor vendor = vendorRepository.findById(id)
                .orElseThrow(() -> new VendorNotFoundException("Vendor not found with id: " + id));

        vendor.setName(request.getName());
        vendor.setContactPerson(request.getContactPerson());
        vendor.setEmail(request.getEmail());
        vendor.setPhone(request.getPhone());
        vendor.setAddress(request.getAddress());
        vendor.setGstNumber(request.getGstNumber());

        Vendor updated = vendorRepository.save(vendor);
        return mapToResponse(updated);
    }

    @Override
    @Transactional(readOnly = true)
    public VendorResponse getVendorById(Long id) {
        Vendor vendor = vendorRepository.findById(id)
                .orElseThrow(() -> new VendorNotFoundException("Vendor not found with id: " + id));
        return mapToResponse(vendor);
    }

    @Override
    @Transactional(readOnly = true)
    public PageResponse<VendorResponse> getAllVendors(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Vendor> vendorPage = vendorRepository.findAll(pageable);

        return PageResponse.<VendorResponse>builder()
                .content(vendorPage.getContent().stream().map(this::mapToResponse).toList())
                .pageNumber(vendorPage.getNumber())
                .pageSize(vendorPage.getSize())
                .totalElements(vendorPage.getTotalElements())
                .totalPages(vendorPage.getTotalPages())
                .last(vendorPage.isLast())
                .build();
    }

    @Override
    public void deleteVendor(Long id) {
        Vendor vendor = vendorRepository.findById(id)
                .orElseThrow(() -> new VendorNotFoundException("Vendor not found with id: " + id));
        vendor.setActive(false);
        vendorRepository.save(vendor);
    }

    private VendorResponse mapToResponse(Vendor vendor) {
        return VendorResponse.builder()
                .id(vendor.getId())
                .name(vendor.getName())
                .contactPerson(vendor.getContactPerson())
                .email(vendor.getEmail())
                .phone(vendor.getPhone())
                .address(vendor.getAddress())
                .gstNumber(vendor.getGstNumber())
                .active(vendor.getActive())
                .createdAt(vendor.getCreatedAt())
                .build();
    }
}