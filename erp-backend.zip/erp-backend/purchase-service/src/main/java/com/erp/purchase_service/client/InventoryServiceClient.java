package com.erp.purchase_service.client;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "inventory-service")
public interface InventoryServiceClient {

    @PostMapping("/api/v1/stock/increase")
    void increaseStock(@RequestBody StockIncreaseRequest request);

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    class StockIncreaseRequest {
        private Long productId;
        private Integer quantity;
        private String referenceType;
        private String referenceNumber;
    }
}