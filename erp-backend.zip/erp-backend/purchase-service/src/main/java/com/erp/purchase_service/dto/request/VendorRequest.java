package com.erp.purchase_service.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VendorRequest {

    @NotBlank(message = "Vendor name is required")
    private String name;

    private String contactPerson;

    @Email(message = "Email must be valid")
    private String email;

    private String phone;
    private String address;
    private String gstNumber;
}