package com.erp.purchase_service.enums;

public enum PurchaseOrderStatus {
    DRAFT,
    CONFIRMED,
    PARTIALLY_RECEIVED,
    FULLY_RECEIVED,
    CANCELLED
}