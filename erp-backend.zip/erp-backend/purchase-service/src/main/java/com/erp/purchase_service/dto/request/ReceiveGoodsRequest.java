package com.erp.purchase_service.dto.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReceiveGoodsRequest {

    @NotEmpty(message = "At least one line item must be received")
    @Valid
    private List<ReceiveLineItem> items;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ReceiveLineItem {

        @NotNull(message = "Line ID is required")
        private Long lineId;

        @Min(value = 1, message = "Received quantity must be at least 1")
        private Integer receivedQuantity;
    }
}