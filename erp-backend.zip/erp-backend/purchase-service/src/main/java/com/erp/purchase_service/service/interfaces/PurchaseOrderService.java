package com.erp.purchase_service.service.interfaces;

import com.erp.common.response.PageResponse;
import com.erp.purchase_service.dto.request.PurchaseOrderRequest;
import com.erp.purchase_service.dto.request.ReceiveGoodsRequest;
import com.erp.purchase_service.dto.response.PurchaseOrderResponse;

public interface PurchaseOrderService {

    PurchaseOrderResponse createPurchaseOrder(PurchaseOrderRequest request);

    PurchaseOrderResponse updatePurchaseOrder(Long id, PurchaseOrderRequest request);

    PurchaseOrderResponse getPurchaseOrderById(Long id);

    PageResponse<PurchaseOrderResponse> getAllPurchaseOrders(int page, int size);

    PurchaseOrderResponse confirmPurchaseOrder(Long id);

    PurchaseOrderResponse receiveGoods(Long id, ReceiveGoodsRequest request);

    void cancelPurchaseOrder(Long id);
}