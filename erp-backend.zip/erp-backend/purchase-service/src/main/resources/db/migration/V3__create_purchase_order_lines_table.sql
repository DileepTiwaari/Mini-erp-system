CREATE TABLE purchase_order_lines (
                                      id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                      purchase_order_id BIGINT NOT NULL,
                                      product_id BIGINT NOT NULL,
                                      product_name VARCHAR(255) NOT NULL,
                                      quantity INT NOT NULL,
                                      received_quantity INT NOT NULL DEFAULT 0,
                                      unit_price DECIMAL(15,2) NOT NULL,
                                      line_total DECIMAL(15,2),
                                      CONSTRAINT fk_line_purchase_order FOREIGN KEY (purchase_order_id) REFERENCES purchase_orders(id) ON DELETE CASCADE
);