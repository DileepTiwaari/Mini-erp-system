CREATE TABLE vendors (
                         id BIGINT AUTO_INCREMENT PRIMARY KEY,
                         name VARCHAR(255) NOT NULL,
                         contact_person VARCHAR(255),
                         email VARCHAR(255),
                         phone VARCHAR(50),
                         address VARCHAR(500),
                         gst_number VARCHAR(50),
                         active BOOLEAN NOT NULL DEFAULT TRUE,
                         created_at DATETIME NOT NULL,
                         updated_at DATETIME NOT NULL
);