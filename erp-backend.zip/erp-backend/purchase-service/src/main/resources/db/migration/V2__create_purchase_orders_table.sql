CREATE TABLE purchase_orders (
                                 id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                 po_number VARCHAR(50) NOT NULL UNIQUE,
                                 vendor_id BIGINT NOT NULL,
                                 status VARCHAR(30) NOT NULL,
                                 order_date DATE NOT NULL,
                                 expected_delivery_date DATE,
                                 total_amount DECIMAL(15,2),
                                 created_by VARCHAR(255),
                                 created_at DATETIME NOT NULL,
                                 updated_at DATETIME NOT NULL,
                                 CONSTRAINT fk_purchase_order_vendor FOREIGN KEY (vendor_id) REFERENCES vendors(id)
);