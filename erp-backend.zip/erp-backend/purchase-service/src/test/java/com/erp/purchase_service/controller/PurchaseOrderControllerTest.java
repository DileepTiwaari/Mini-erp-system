package com.erp.purchase_service.controller;

import com.erp.purchase_service.dto.request.PurchaseOrderLineRequest;
import com.erp.purchase_service.dto.request.PurchaseOrderRequest;
import com.erp.purchase_service.dto.response.PurchaseOrderLineResponse;
import com.erp.purchase_service.dto.response.PurchaseOrderResponse;
import com.erp.purchase_service.enums.PurchaseOrderStatus;
import com.erp.purchase_service.exception.PurchaseOrderNotFoundException;
import com.erp.purchase_service.service.interfaces.PurchaseOrderService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(PurchaseOrderController.class)
@WithMockUser
class PurchaseOrderControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private PurchaseOrderService purchaseOrderService;

    private PurchaseOrderResponse sampleResponse;
    private PurchaseOrderRequest sampleRequest;

    @BeforeEach
    void setUp() {
        PurchaseOrderLineResponse line = PurchaseOrderLineResponse.builder()
                .id(1L)
                .productId(10L)
                .productName("Wooden Leg")
                .quantity(40)
                .receivedQuantity(0)
                .unitPrice(BigDecimal.valueOf(50))
                .lineTotal(BigDecimal.valueOf(2000))
                .build();

        sampleResponse = PurchaseOrderResponse.builder()
                .id(1L)
                .poNumber("PO-20260620-0001")
                .vendorId(5L)
                .vendorName("ABC Timber Supplies")
                .status(PurchaseOrderStatus.DRAFT)
                .orderDate(LocalDate.now())
                .expectedDeliveryDate(LocalDate.now().plusDays(7))
                .totalAmount(BigDecimal.valueOf(2000))
                .lines(List.of(line))
                .build();

        PurchaseOrderLineRequest lineRequest = PurchaseOrderLineRequest.builder()
                .productId(10L)
                .productName("Wooden Leg")
                .quantity(40)
                .unitPrice(BigDecimal.valueOf(50))
                .build();

        sampleRequest = PurchaseOrderRequest.builder()
                .vendorId(5L)
                .expectedDeliveryDate(LocalDate.now().plusDays(7))
                .lines(List.of(lineRequest))
                .build();
    }

    @Test
    void createPurchaseOrder_shouldReturnCreated() throws Exception {
        when(purchaseOrderService.createPurchaseOrder(any(PurchaseOrderRequest.class)))
                .thenReturn(sampleResponse);

        mockMvc.perform(post("/api/v1/purchase-orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sampleRequest)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.poNumber").value("PO-20260620-0001"))
                .andExpect(jsonPath("$.data.status").value("DRAFT"));
    }

    @Test
    void createPurchaseOrder_shouldReturnBadRequest_whenLinesEmpty() throws Exception {
        PurchaseOrderRequest invalidRequest = PurchaseOrderRequest.builder()
                .vendorId(5L)
                .lines(List.of())
                .build();

        mockMvc.perform(post("/api/v1/purchase-orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalidRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void getPurchaseOrderById_shouldReturnOrder() throws Exception {
        when(purchaseOrderService.getPurchaseOrderById(1L)).thenReturn(sampleResponse);

        mockMvc.perform(get("/api/v1/purchase-orders/{id}", 1L))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.id").value(1L))
                .andExpect(jsonPath("$.data.vendorName").value("ABC Timber Supplies"));
    }

    @Test
    void getPurchaseOrderById_shouldReturnNotFound_whenMissing() throws Exception {
        when(purchaseOrderService.getPurchaseOrderById(99L))
                .thenThrow(new PurchaseOrderNotFoundException("Purchase order not found with id: 99"));

        mockMvc.perform(get("/api/v1/purchase-orders/{id}", 99L))
                .andExpect(status().isNotFound());
    }

    @Test
    void confirmPurchaseOrder_shouldReturnConfirmedOrder() throws Exception {
        PurchaseOrderResponse confirmed = PurchaseOrderResponse.builder()
                .id(1L)
                .poNumber("PO-20260620-0001")
                .status(PurchaseOrderStatus.CONFIRMED)
                .build();

        when(purchaseOrderService.confirmPurchaseOrder(eq(1L))).thenReturn(confirmed);

        mockMvc.perform(put("/api/v1/purchase-orders/{id}/confirm", 1L))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("CONFIRMED"));
    }

    @Test
    void cancelPurchaseOrder_shouldReturnOk() throws Exception {
        mockMvc.perform(put("/api/v1/purchase-orders/{id}/cancel", 1L))
                .andExpect(status().isOk());
    }
}