package com.erp.purchase_service.integration;

import com.erp.purchase_service.client.InventoryServiceClient;
import com.erp.purchase_service.dto.request.PurchaseOrderLineRequest;
import com.erp.purchase_service.dto.request.PurchaseOrderRequest;
import com.erp.purchase_service.dto.request.VendorRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.math.BigDecimal;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@ActiveProfiles("dev")
@WithMockUser
class PurchaseIntegrationTest {

    @Autowired
    private WebApplicationContext context;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private InventoryServiceClient inventoryServiceClient;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    @Test
    void fullPurchaseOrderLifecycle_createConfirmReceive() throws Exception {
        VendorRequest vendorRequest = VendorRequest.builder()
                .name("Integration Test Vendor")
                .email("vendor@example.com")
                .phone("9999999999")
                .build();

        String vendorResponseJson = mockMvc.perform(post("/api/v1/vendors")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(vendorRequest)))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();

        Long vendorId = objectMapper.readTree(vendorResponseJson)
                .get("data").get("id").asLong();

        PurchaseOrderLineRequest lineRequest = PurchaseOrderLineRequest.builder()
                .productId(100L)
                .productName("Integration Test Component")
                .quantity(20)
                .unitPrice(BigDecimal.valueOf(25))
                .build();

        PurchaseOrderRequest poRequest = PurchaseOrderRequest.builder()
                .vendorId(vendorId)
                .lines(List.of(lineRequest))
                .build();

        String poResponseJson = mockMvc.perform(post("/api/v1/purchase-orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(poRequest)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.status").value("DRAFT"))
                .andReturn().getResponse().getContentAsString();

        Long poId = objectMapper.readTree(poResponseJson).get("data").get("id").asLong();
        Long lineId = objectMapper.readTree(poResponseJson)
                .get("data").get("lines").get(0).get("id").asLong();

        mockMvc.perform(put("/api/v1/purchase-orders/{id}/confirm", poId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("CONFIRMED"));

        doNothing().when(inventoryServiceClient).increaseStock(any());

        String receiveBody = String.format(
                "{\"items\":[{\"lineId\":%d,\"receivedQuantity\":20}]}", lineId);

        mockMvc.perform(post("/api/v1/purchase-orders/{id}/receive", poId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(receiveBody))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("FULLY_RECEIVED"));
    }

    @Test
    void getPurchaseOrderById_shouldReturnNotFound_forNonExistentId() throws Exception {
        mockMvc.perform(get("/api/v1/purchase-orders/{id}", 999999L))
                .andExpect(status().isNotFound());
    }
}