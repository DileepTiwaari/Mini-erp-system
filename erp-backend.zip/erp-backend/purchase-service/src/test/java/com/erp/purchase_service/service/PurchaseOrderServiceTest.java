package com.erp.purchase_service.service;

import com.erp.purchase_service.client.InventoryServiceClient;
import com.erp.purchase_service.dto.request.PurchaseOrderLineRequest;
import com.erp.purchase_service.dto.request.PurchaseOrderRequest;
import com.erp.purchase_service.dto.request.ReceiveGoodsRequest;
import com.erp.purchase_service.dto.response.PurchaseOrderResponse;
import com.erp.purchase_service.entity.PurchaseOrder;
import com.erp.purchase_service.entity.PurchaseOrderLine;
import com.erp.purchase_service.entity.Vendor;
import com.erp.purchase_service.enums.PurchaseOrderStatus;
import com.erp.purchase_service.exception.InvalidOrderStateException;
import com.erp.purchase_service.exception.PurchaseOrderNotFoundException;
import com.erp.purchase_service.exception.VendorNotFoundException;
import com.erp.purchase_service.repository.PurchaseOrderRepository;
import com.erp.purchase_service.repository.VendorRepository;
import com.erp.purchase_service.service.impl.PurchaseOrderServiceImpl;
import com.erp.purchase_service.util.PurchaseUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PurchaseOrderServiceTest {

    @Mock
    private PurchaseOrderRepository purchaseOrderRepository;

    @Mock
    private VendorRepository vendorRepository;

    @Mock
    private InventoryServiceClient inventoryServiceClient;

    @Mock
    private PurchaseUtil purchaseUtil;

    @InjectMocks
    private PurchaseOrderServiceImpl purchaseOrderService;

    private Vendor vendor;
    private PurchaseOrderRequest request;

    @BeforeEach
    void setUp() {
        vendor = Vendor.builder()
                .id(5L)
                .name("ABC Timber Supplies")
                .active(true)
                .build();

        PurchaseOrderLineRequest lineRequest = PurchaseOrderLineRequest.builder()
                .productId(10L)
                .productName("Wooden Leg")
                .quantity(40)
                .unitPrice(BigDecimal.valueOf(50))
                .build();

        request = PurchaseOrderRequest.builder()
                .vendorId(5L)
                .lines(List.of(lineRequest))
                .build();
    }

    @Test
    void createPurchaseOrder_shouldCreateSuccessfully() {
        when(vendorRepository.findById(5L)).thenReturn(Optional.of(vendor));
        when(purchaseUtil.generatePoNumber()).thenReturn("PO-20260620-0001");
        when(purchaseOrderRepository.save(any(PurchaseOrder.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        PurchaseOrderResponse response = purchaseOrderService.createPurchaseOrder(request);

        assertThat(response.getPoNumber()).isEqualTo("PO-20260620-0001");
        assertThat(response.getVendorName()).isEqualTo("ABC Timber Supplies");
        assertThat(response.getTotalAmount()).isEqualTo(BigDecimal.valueOf(2000));
        assertThat(response.getStatus()).isEqualTo(PurchaseOrderStatus.DRAFT);
        verify(purchaseOrderRepository, times(1)).save(any(PurchaseOrder.class));
    }

    @Test
    void createPurchaseOrder_shouldThrow_whenVendorNotFound() {
        when(vendorRepository.findById(5L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> purchaseOrderService.createPurchaseOrder(request))
                .isInstanceOf(VendorNotFoundException.class);

        verify(purchaseOrderRepository, never()).save(any(PurchaseOrder.class));
    }

    @Test
    void confirmPurchaseOrder_shouldChangeStatusToConfirmed() {
        PurchaseOrder order = buildDraftOrder();

        when(purchaseOrderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(purchaseOrderRepository.save(any(PurchaseOrder.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        PurchaseOrderResponse response = purchaseOrderService.confirmPurchaseOrder(1L);

        assertThat(response.getStatus()).isEqualTo(PurchaseOrderStatus.CONFIRMED);
    }

    @Test
    void confirmPurchaseOrder_shouldThrow_whenNotDraft() {
        PurchaseOrder order = buildDraftOrder();
        order.setStatus(PurchaseOrderStatus.CONFIRMED);

        when(purchaseOrderRepository.findById(1L)).thenReturn(Optional.of(order));

        assertThatThrownBy(() -> purchaseOrderService.confirmPurchaseOrder(1L))
                .isInstanceOf(InvalidOrderStateException.class);
    }

    @Test
    void confirmPurchaseOrder_shouldThrow_whenOrderNotFound() {
        when(purchaseOrderRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> purchaseOrderService.confirmPurchaseOrder(99L))
                .isInstanceOf(PurchaseOrderNotFoundException.class);
    }

    @Test
    void receiveGoods_shouldIncreaseStockAndUpdateStatusToFullyReceived() {
        PurchaseOrder order = buildDraftOrder();
        order.setStatus(PurchaseOrderStatus.CONFIRMED);
        PurchaseOrderLine line = order.getLines().get(0);
        line.setId(1L);

        ReceiveGoodsRequest.ReceiveLineItem item = ReceiveGoodsRequest.ReceiveLineItem.builder()
                .lineId(1L)
                .receivedQuantity(40)
                .build();
        ReceiveGoodsRequest receiveRequest = ReceiveGoodsRequest.builder()
                .items(List.of(item))
                .build();

        when(purchaseOrderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(purchaseOrderRepository.save(any(PurchaseOrder.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        PurchaseOrderResponse response = purchaseOrderService.receiveGoods(1L, receiveRequest);

        assertThat(response.getStatus()).isEqualTo(PurchaseOrderStatus.FULLY_RECEIVED);
        verify(inventoryServiceClient, times(1)).increaseStock(any());
    }

    @Test
    void receiveGoods_shouldThrow_whenReceivedQuantityExceedsOrdered() {
        PurchaseOrder order = buildDraftOrder();
        order.setStatus(PurchaseOrderStatus.CONFIRMED);
        PurchaseOrderLine line = order.getLines().get(0);
        line.setId(1L);

        ReceiveGoodsRequest.ReceiveLineItem item = ReceiveGoodsRequest.ReceiveLineItem.builder()
                .lineId(1L)
                .receivedQuantity(999)
                .build();
        ReceiveGoodsRequest receiveRequest = ReceiveGoodsRequest.builder()
                .items(List.of(item))
                .build();

        when(purchaseOrderRepository.findById(1L)).thenReturn(Optional.of(order));

        assertThatThrownBy(() -> purchaseOrderService.receiveGoods(1L, receiveRequest))
                .isInstanceOf(InvalidOrderStateException.class);

        verify(inventoryServiceClient, never()).increaseStock(any());
    }

    @Test
    void cancelPurchaseOrder_shouldThrow_whenFullyReceived() {
        PurchaseOrder order = buildDraftOrder();
        order.setStatus(PurchaseOrderStatus.FULLY_RECEIVED);

        when(purchaseOrderRepository.findById(1L)).thenReturn(Optional.of(order));

        assertThatThrownBy(() -> purchaseOrderService.cancelPurchaseOrder(1L))
                .isInstanceOf(InvalidOrderStateException.class);

        verify(purchaseOrderRepository, never()).save(any(PurchaseOrder.class));
    }

    private PurchaseOrder buildDraftOrder() {
        PurchaseOrder order = PurchaseOrder.builder()
                .id(1L)
                .poNumber("PO-20260620-0001")
                .vendor(vendor)
                .status(PurchaseOrderStatus.DRAFT)
                .totalAmount(BigDecimal.valueOf(2000))
                .build();

        PurchaseOrderLine line = PurchaseOrderLine.builder()
                .productId(10L)
                .productName("Wooden Leg")
                .quantity(40)
                .receivedQuantity(0)
                .unitPrice(BigDecimal.valueOf(50))
                .lineTotal(BigDecimal.valueOf(2000))
                .build();

        order.addLine(line);
        return order;
    }
}