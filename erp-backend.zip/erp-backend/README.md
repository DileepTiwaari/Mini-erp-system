# Mini ERP — Shiv Furniture Works

A modular Mini ERP backend built with Spring Boot 4.1.0 microservices,
covering Product Management, Sales, Purchase, Manufacturing, Bill of
Materials (BoM), Inventory & Stock Tracking, Procurement Automation,
Audit Logs, and Role-Based Access Control.

## Tech Stack

- **Java 17**
- **Spring Boot 4.1.0**
- **Spring Cloud 2025.1.2** (Eureka, Config Server, Gateway, OpenFeign)
- **MySQL 8.4** (database-per-service)
- **Flyway** (schema migrations)
- **Maven** (multi-module build)
- **Lombok**
- **Springdoc OpenAPI 3.0.3** (Swagger UI per service)

## Architecture

This is a multi-module Maven project. Each service is independently
runnable, registers with Eureka, and pulls shared config from Config
Server. The API Gateway is the single entry point for all external
requests.

| Service | Port | Responsibility |
|---|---|---|
| config-server | 8888 | Centralized configuration |
| eureka-server | 8761 | Service discovery |
| api-gateway | 8080 | Single entry point, JWT auth, routing |
| auth-service | 8081 | Users, roles, JWT issuing |
| product-service | 8082 | Products, categories, stock config |
| sales-service | 8083 | Customers, sales orders, deliveries |
| purchase-service | 8084 | Vendors, purchase orders, receiving |
| bom-service | 8085 | Bill of Materials, components, operations, work centers |
| manufacturing-service | 8086 | Manufacturing orders, work orders |
| inventory-service | 8087 | Stock, stock ledger (single source of truth) |
| procurement-service | 8088 | MTS/MTO automation engine |
| audit-service | 8089 | Audit logs, dashboard analytics |

## Prerequisites

- Java 17 (JDK)
- Maven 3.9+ (or use included `mvnw`)
- Docker Desktop (for MySQL)
- IntelliJ IDEA
- SQLyog (or any MySQL GUI client)

## Getting Started

### 1. Start MySQL

```bash
docker-compose up -d
```

This starts a MySQL 8.4 container on `localhost:3306`. Each service
auto-creates its own database on first startup
(`createDatabaseIfNotExist=true`).

### 2. Build all modules

```bash
mvn clean install
```

### 3. Run services in this order

Boot order matters — infrastructure first, then business services,
gateway last:

1. `config-server`
2. `eureka-server`
3. `auth-service`
4. `product-service`
5. `inventory-service`
6. `bom-service`
7. `purchase-service`
8. `sales-service`
9. `manufacturing-service`
10. `procurement-service`
11. `audit-service`
12. `api-gateway`

Run each from IntelliJ (right-click `*Application.java` → Run), or via:

```bash
cd <service-folder>
mvn spring-boot:run
```

### 4. Verify services are registered

Open Eureka dashboard: `http://localhost:8761`

### 5. Access Swagger UI per service

Example: `http://localhost:8083/swagger-ui.html` (sales-service)

### 6. Access via Gateway (recommended for frontend integration)

All requests should go through: `http://localhost:8080/api/v1/...`

## Core Business Flow