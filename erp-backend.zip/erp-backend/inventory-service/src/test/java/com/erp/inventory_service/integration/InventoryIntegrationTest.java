package com.erp.inventory_service.integration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryIntegrationTest {
    @Test
    void contextLoads() {
    }
}