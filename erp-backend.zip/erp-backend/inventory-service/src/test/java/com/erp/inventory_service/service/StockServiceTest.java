package com.erp.inventory_service.service;

import org.junit.jupiter.api.Test;

class StockServiceTest {
    @Test
    void placeholderTest() {
    }
}