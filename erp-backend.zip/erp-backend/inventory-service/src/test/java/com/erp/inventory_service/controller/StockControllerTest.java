package com.erp.inventory_service.controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockControllerTest {
    @Test
    void contextLoads() {
    }
}