-- V1: Create stock table
CREATE TABLE stock (
                       id BIGINT AUTO_INCREMENT PRIMARY KEY,
                       product_id BIGINT NOT NULL UNIQUE,
                       on_hand_qty INT NOT NULL DEFAULT 0,
                       reserved_qty INT NOT NULL DEFAULT 0,
                       updated_at DATETIME NOT NULL
);

CREATE INDEX idx_stock_product ON stock(product_id);