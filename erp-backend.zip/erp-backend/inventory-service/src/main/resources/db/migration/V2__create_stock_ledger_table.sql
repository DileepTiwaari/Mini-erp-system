-- V2: Create stock_ledger table
CREATE TABLE stock_ledger (
                              id BIGINT AUTO_INCREMENT PRIMARY KEY,
                              product_id BIGINT NOT NULL,
                              movement_type VARCHAR(30) NOT NULL,
                              qty INT NOT NULL,
                              balance_after_movement INT NOT NULL,
                              reference_id VARCHAR(50),
                              reference_type VARCHAR(30),
                              created_at DATETIME NOT NULL,
                              created_by VARCHAR(50)
);

CREATE INDEX idx_ledger_product ON stock_ledger(product_id);
CREATE INDEX idx_ledger_created_at ON stock_ledger(created_at);