package com.erp.inventory_service.dto.response;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StockResponse {
    private Long productId;
    private Integer onHandQty;
    private Integer reservedQty;
    private Integer freeToUseQty;
}