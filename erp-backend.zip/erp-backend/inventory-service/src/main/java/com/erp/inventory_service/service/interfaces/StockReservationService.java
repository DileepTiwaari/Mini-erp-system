package com.erp.inventory_service.service.interfaces;

public interface StockReservationService {

    void reserve(Long productId, Integer qty, String referenceId, String referenceType);

    void release(Long productId, Integer qty, String referenceId, String referenceType);
}