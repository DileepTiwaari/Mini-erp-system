package com.erp.inventory_service.repository;

import com.erp.inventory_service.entity.Stock;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface StockRepository extends JpaRepository<Stock, Long> {

    Optional<Stock> findByProductId(Long productId);

    @Query("SELECT s FROM Stock s WHERE (s.onHandQty - s.reservedQty) <= :threshold")
    List<Stock> findLowStock(@Param("threshold") int threshold);

    Page<Stock> findAll(Pageable pageable);
}