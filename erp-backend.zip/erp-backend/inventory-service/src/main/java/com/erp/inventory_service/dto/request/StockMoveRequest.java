package com.erp.inventory_service.dto.request;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StockMoveRequest {

    @NotNull(message = "Product ID is required")
    private Long productId;

    @NotNull(message = "Quantity is required")
    @Min(value = 1, message = "Quantity must be at least 1")
    private Integer qty;

    @NotBlank(message = "Movement type is required")
    private String movementType;

    @NotBlank(message = "Reference ID is required")
    private String referenceId;

    @NotBlank(message = "Reference type is required")
    private String referenceType;
}