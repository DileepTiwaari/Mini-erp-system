package com.erp.inventory_service.repository;

import com.erp.inventory_service.entity.StockLedger;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StockLedgerRepository extends JpaRepository<StockLedger, Long> {

    Page<StockLedger> findByProductId(Long productId, Pageable pageable);
}