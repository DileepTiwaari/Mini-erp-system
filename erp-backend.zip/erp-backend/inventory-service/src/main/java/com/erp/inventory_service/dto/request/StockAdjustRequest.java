package com.erp.inventory_service.dto.request;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StockAdjustRequest {

    @NotNull(message = "Product ID is required")
    private Long productId;

    @NotNull(message = "New quantity is required")
    @Min(value = 0, message = "New quantity cannot be negative")
    private Integer newQty;

    @NotBlank(message = "Reason is required")
    private String reason;
}