package com.erp.inventory_service.service.interfaces;

import com.erp.inventory_service.dto.request.StockAdjustRequest;
import com.erp.inventory_service.dto.request.StockMoveRequest;
import com.erp.inventory_service.dto.response.StockResponse;
import com.erp.inventory_service.dto.response.StockValuationResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.util.List;

public interface StockService {

    StockResponse getStock(Long productId);

    Page<StockResponse> getAllStock(Pageable pageable);

    void moveStock(StockMoveRequest request);

    void adjustStock(StockAdjustRequest request);

    StockValuationResponse getValuation(Long productId, BigDecimal costPrice);

    List<StockResponse> getLowStock(int threshold);
}