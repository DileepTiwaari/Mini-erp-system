package com.erp.inventory_service.dto.response;

import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StockValuationResponse {
    private Long productId;
    private Integer onHandQty;
    private BigDecimal costPrice;
    private BigDecimal totalValue;
}