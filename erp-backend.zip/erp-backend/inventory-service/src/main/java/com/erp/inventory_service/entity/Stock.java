package com.erp.inventory_service.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "stock")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Stock {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "product_id", nullable = false, unique = true)
    private Long productId;

    @Builder.Default
    @Column(name = "on_hand_qty", nullable = false)
    private Integer onHandQty = 0;

    @Builder.Default
    @Column(name = "reserved_qty", nullable = false)
    private Integer reservedQty = 0;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Transient
    public Integer getFreeToUseQty() {
        return (onHandQty == null ? 0 : onHandQty) - (reservedQty == null ? 0 : reservedQty);
    }

    @PrePersist
    @PreUpdate
    protected void onSave() {
        this.updatedAt = LocalDateTime.now();
        if (this.onHandQty == null) this.onHandQty = 0;
        if (this.reservedQty == null) this.reservedQty = 0;
    }
}