package com.erp.inventory_service.util;

import com.erp.inventory_service.enums.MovementType;

import java.util.Set;

public class InventoryUtil {

    private static final Set<MovementType> INBOUND_TYPES =
            Set.of(MovementType.PURCHASE_RECEIPT, MovementType.MO_PRODUCE);

    private static final Set<MovementType> OUTBOUND_TYPES =
            Set.of(MovementType.SALE_DELIVERY, MovementType.MO_CONSUME);

    private InventoryUtil() {
    }

    public static boolean isInbound(MovementType type) {
        return INBOUND_TYPES.contains(type);
    }

    public static boolean isOutbound(MovementType type) {
        return OUTBOUND_TYPES.contains(type);
    }
}