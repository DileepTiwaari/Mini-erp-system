package com.erp.inventory_service.exception;

public class StockNotFoundException extends RuntimeException {

    public StockNotFoundException(Long productId) {
        super("Stock record not found for product id: " + productId);
    }
}