package com.erp.inventory_service.controller;

import com.erp.inventory_service.dto.response.ApiResponse;
import com.erp.inventory_service.dto.response.StockLedgerResponse;
import com.erp.inventory_service.service.interfaces.StockLedgerService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/stock/ledger")
@RequiredArgsConstructor
public class StockLedgerController {

    private final StockLedgerService stockLedgerService;

    @GetMapping
    public ApiResponse<Page<StockLedgerResponse>> getLedger(
            @PageableDefault(size = 20, sort = "createdAt") Pageable pageable) {
        return ApiResponse.success(stockLedgerService.getLedger(pageable));
    }

    @GetMapping("/{productId}")
    public ApiResponse<Page<StockLedgerResponse>> getLedgerByProduct(
            @PathVariable Long productId,
            @PageableDefault(size = 20, sort = "createdAt") Pageable pageable) {
        return ApiResponse.success(stockLedgerService.getLedgerByProduct(productId, pageable));
    }
}