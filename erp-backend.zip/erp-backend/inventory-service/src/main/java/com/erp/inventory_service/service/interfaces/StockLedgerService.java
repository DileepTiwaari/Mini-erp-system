package com.erp.inventory_service.service.interfaces;

import com.erp.inventory_service.enums.MovementType;
import com.erp.inventory_service.dto.response.StockLedgerResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface StockLedgerService {

    void recordMovement(Long productId, MovementType movementType, Integer signedQty,
                        Integer balanceAfterMovement, String referenceId, String referenceType);

    Page<StockLedgerResponse> getLedger(Pageable pageable);

    Page<StockLedgerResponse> getLedgerByProduct(Long productId, Pageable pageable);
}