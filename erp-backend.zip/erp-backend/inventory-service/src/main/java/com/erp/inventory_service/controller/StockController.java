package com.erp.inventory_service.controller;

import com.erp.inventory_service.dto.request.StockAdjustRequest;
import com.erp.inventory_service.dto.request.StockMoveRequest;
import com.erp.inventory_service.dto.request.StockReleaseRequest;
import com.erp.inventory_service.dto.request.StockReserveRequest;
import com.erp.inventory_service.dto.response.ApiResponse;
import com.erp.inventory_service.dto.response.StockResponse;
import com.erp.inventory_service.dto.response.StockValuationResponse;
import com.erp.inventory_service.service.interfaces.StockReservationService;
import com.erp.inventory_service.service.interfaces.StockService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/v1/stock")
@RequiredArgsConstructor
public class StockController {

    private final StockService stockService;
    private final StockReservationService stockReservationService;

    @GetMapping
    public ApiResponse<Page<StockResponse>> getAllStock(
            @PageableDefault(size = 20, sort = "id") Pageable pageable) {
        return ApiResponse.success(stockService.getAllStock(pageable));
    }

    @GetMapping("/{productId}")
    public ApiResponse<StockResponse> getStock(@PathVariable Long productId) {
        return ApiResponse.success(stockService.getStock(productId));
    }

    @GetMapping("/low-stock")
    public ApiResponse<List<StockResponse>> getLowStock(
            @RequestParam(defaultValue = "10") int threshold) {
        return ApiResponse.success(stockService.getLowStock(threshold));
    }

    @PostMapping("/reserve")
    public ApiResponse<Void> reserveStock(@Valid @RequestBody StockReserveRequest request) {
        stockReservationService.reserve(
                request.getProductId(), request.getQty(), request.getReferenceId(), request.getReferenceType());
        return ApiResponse.success("Stock reserved successfully", null);
    }

    @PostMapping("/release")
    public ApiResponse<Void> releaseStock(@Valid @RequestBody StockReleaseRequest request) {
        stockReservationService.release(
                request.getProductId(), request.getQty(), request.getReferenceId(), request.getReferenceType());
        return ApiResponse.success("Stock released successfully", null);
    }

    @PostMapping("/move")
    public ApiResponse<Void> moveStock(@Valid @RequestBody StockMoveRequest request) {
        stockService.moveStock(request);
        return ApiResponse.success("Stock moved successfully", null);
    }

    @PostMapping("/adjust")
    public ApiResponse<Void> adjustStock(@Valid @RequestBody StockAdjustRequest request) {
        stockService.adjustStock(request);
        return ApiResponse.success("Stock adjusted successfully", null);
    }

    @GetMapping("/valuation")
    public ApiResponse<StockValuationResponse> getValuation(
            @RequestParam Long productId,
            @RequestParam(required = false) BigDecimal costPrice) {
        return ApiResponse.success(stockService.getValuation(productId, costPrice));
    }
}