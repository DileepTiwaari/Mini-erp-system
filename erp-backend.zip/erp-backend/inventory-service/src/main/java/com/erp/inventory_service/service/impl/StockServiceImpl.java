package com.erp.inventory_service.service.impl;

import com.erp.inventory_service.dto.request.StockAdjustRequest;
import com.erp.inventory_service.dto.request.StockMoveRequest;
import com.erp.inventory_service.dto.response.StockResponse;
import com.erp.inventory_service.dto.response.StockValuationResponse;
import com.erp.inventory_service.entity.Stock;
import com.erp.inventory_service.enums.MovementType;
import com.erp.inventory_service.repository.StockRepository;
import com.erp.inventory_service.service.interfaces.StockLedgerService;
import com.erp.inventory_service.service.interfaces.StockService;
import com.erp.inventory_service.util.InventoryUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class StockServiceImpl implements StockService {

    private final StockRepository stockRepository;
    private final StockLedgerService stockLedgerService;

    @Override
    @Transactional(readOnly = true)
    public StockResponse getStock(Long productId) {
        Stock stock = findOrCreate(productId);
        return toResponse(stock);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<StockResponse> getAllStock(Pageable pageable) {
        return stockRepository.findAll(pageable).map(this::toResponse);
    }

    @Override
    public void moveStock(StockMoveRequest request) {
        MovementType movementType;
        try {
            movementType = MovementType.valueOf(request.getMovementType().toUpperCase());
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("Invalid movement type: " + request.getMovementType());
        }

        Stock stock = findOrCreate(request.getProductId());
        int signedQty;

        if (InventoryUtil.isInbound(movementType)) {
            stock.setOnHandQty(stock.getOnHandQty() + request.getQty());
            signedQty = request.getQty();
        } else if (InventoryUtil.isOutbound(movementType)) {
            stock.setOnHandQty(Math.max(0, stock.getOnHandQty() - request.getQty()));
            signedQty = -request.getQty();
        } else {
            // ADJUSTMENT via /move endpoint treated as inbound by default
            stock.setOnHandQty(stock.getOnHandQty() + request.getQty());
            signedQty = request.getQty();
        }

        stockRepository.save(stock);

        stockLedgerService.recordMovement(
                request.getProductId(), movementType, signedQty,
                stock.getOnHandQty(), request.getReferenceId(), request.getReferenceType());
    }

    @Override
    public void adjustStock(StockAdjustRequest request) {
        Stock stock = findOrCreate(request.getProductId());
        int delta = request.getNewQty() - stock.getOnHandQty();

        stock.setOnHandQty(request.getNewQty());
        stockRepository.save(stock);

        stockLedgerService.recordMovement(
                request.getProductId(), MovementType.ADJUSTMENT, delta,
                stock.getOnHandQty(), "ADJ-" + System.currentTimeMillis(), "MANUAL_ADJUSTMENT");
    }

    @Override
    @Transactional(readOnly = true)
    public StockValuationResponse getValuation(Long productId, BigDecimal costPrice) {
        Stock stock = findOrCreate(productId);
        BigDecimal price = costPrice != null ? costPrice : BigDecimal.ZERO;
        BigDecimal totalValue = price.multiply(BigDecimal.valueOf(stock.getOnHandQty()));

        return StockValuationResponse.builder()
                .productId(productId)
                .onHandQty(stock.getOnHandQty())
                .costPrice(price)
                .totalValue(totalValue)
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public List<StockResponse> getLowStock(int threshold) {
        return stockRepository.findLowStock(threshold).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    private Stock findOrCreate(Long productId) {
        return stockRepository.findByProductId(productId)
                .orElseGet(() -> stockRepository.save(
                        Stock.builder().productId(productId).onHandQty(0).reservedQty(0).build()));
    }

    private StockResponse toResponse(Stock stock) {
        return StockResponse.builder()
                .productId(stock.getProductId())
                .onHandQty(stock.getOnHandQty())
                .reservedQty(stock.getReservedQty())
                .freeToUseQty(stock.getFreeToUseQty())
                .build();
    }
}