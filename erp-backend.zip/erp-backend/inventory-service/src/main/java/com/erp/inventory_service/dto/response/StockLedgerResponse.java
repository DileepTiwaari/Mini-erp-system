package com.erp.inventory_service.dto.response;

import com.erp.inventory_service.enums.MovementType;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StockLedgerResponse {
    private Long id;
    private Long productId;
    private MovementType movementType;
    private Integer qty;
    private Integer balanceAfterMovement;
    private String referenceId;
    private String referenceType;
    private LocalDateTime createdAt;
    private String createdBy;
}