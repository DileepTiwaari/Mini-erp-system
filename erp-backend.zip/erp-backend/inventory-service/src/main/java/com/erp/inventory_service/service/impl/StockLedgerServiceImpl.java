package com.erp.inventory_service.service.impl;

import com.erp.inventory_service.entity.StockLedger;
import com.erp.inventory_service.enums.MovementType;
import com.erp.inventory_service.dto.response.StockLedgerResponse;
import com.erp.inventory_service.repository.StockLedgerRepository;
import com.erp.inventory_service.service.interfaces.StockLedgerService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class StockLedgerServiceImpl implements StockLedgerService {

    private final StockLedgerRepository stockLedgerRepository;

    @Override
    public void recordMovement(Long productId, MovementType movementType, Integer signedQty,
                               Integer balanceAfterMovement, String referenceId, String referenceType) {
        StockLedger entry = StockLedger.builder()
                .productId(productId)
                .movementType(movementType)
                .qty(signedQty)
                .balanceAfterMovement(balanceAfterMovement)
                .referenceId(referenceId)
                .referenceType(referenceType)
                .build();
        stockLedgerRepository.save(entry);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<StockLedgerResponse> getLedger(Pageable pageable) {
        return stockLedgerRepository.findAll(pageable).map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<StockLedgerResponse> getLedgerByProduct(Long productId, Pageable pageable) {
        return stockLedgerRepository.findByProductId(productId, pageable).map(this::toResponse);
    }

    private StockLedgerResponse toResponse(StockLedger entry) {
        return StockLedgerResponse.builder()
                .id(entry.getId())
                .productId(entry.getProductId())
                .movementType(entry.getMovementType())
                .qty(entry.getQty())
                .balanceAfterMovement(entry.getBalanceAfterMovement())
                .referenceId(entry.getReferenceId())
                .referenceType(entry.getReferenceType())
                .createdAt(entry.getCreatedAt())
                .createdBy(entry.getCreatedBy())
                .build();
    }
}