package com.erp.inventory_service.service.impl;

import com.erp.inventory_service.entity.Stock;
import com.erp.inventory_service.exception.InsufficientStockException;
import com.erp.inventory_service.repository.StockRepository;
import com.erp.inventory_service.service.interfaces.StockReservationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class StockReservationServiceImpl implements StockReservationService {

    private final StockRepository stockRepository;

    @Override
    public void reserve(Long productId, Integer qty, String referenceId, String referenceType) {
        Stock stock = findOrCreate(productId);

        int freeToUse = stock.getOnHandQty() - stock.getReservedQty();
        if (freeToUse < qty) {
            throw new InsufficientStockException(
                    "Cannot reserve " + qty + " units of product " + productId +
                            ". Only " + freeToUse + " available.");
        }

        stock.setReservedQty(stock.getReservedQty() + qty);
        stockRepository.save(stock);
    }

    @Override
    public void release(Long productId, Integer qty, String referenceId, String referenceType) {
        Stock stock = findOrCreate(productId);
        int newReserved = Math.max(0, stock.getReservedQty() - qty);
        stock.setReservedQty(newReserved);
        stockRepository.save(stock);
    }

    private Stock findOrCreate(Long productId) {
        return stockRepository.findByProductId(productId)
                .orElseGet(() -> stockRepository.save(
                        Stock.builder().productId(productId).onHandQty(0).reservedQty(0).build()));
    }
}