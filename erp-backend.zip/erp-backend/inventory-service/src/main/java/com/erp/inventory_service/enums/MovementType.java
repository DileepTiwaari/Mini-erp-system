package com.erp.inventory_service.enums;

public enum MovementType {
    SALE_DELIVERY,
    PURCHASE_RECEIPT,
    MO_CONSUME,
    MO_PRODUCE,
    ADJUSTMENT
}