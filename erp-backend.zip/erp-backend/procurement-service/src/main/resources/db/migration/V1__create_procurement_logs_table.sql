-- V1: Create procurement_logs table
CREATE TABLE procurement_logs (
                                  id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                  product_id BIGINT NOT NULL,
                                  shortage_qty INT NOT NULL,
                                  action_taken VARCHAR(30),
                                  reference_id VARCHAR(50),
                                  reason VARCHAR(500),
                                  triggered_at DATETIME NOT NULL,
                                  triggered_by VARCHAR(50)
);

CREATE INDEX idx_procurement_log_product ON procurement_logs(product_id);
CREATE INDEX idx_procurement_log_triggered_at ON procurement_logs(triggered_at);