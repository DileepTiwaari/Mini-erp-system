package com.erp.procurement_service.repository;

import com.erp.procurement_service.entity.ProcurementLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProcurementLogRepository extends JpaRepository<ProcurementLog, Long> {

    Page<ProcurementLog> findAll(Pageable pageable);
}