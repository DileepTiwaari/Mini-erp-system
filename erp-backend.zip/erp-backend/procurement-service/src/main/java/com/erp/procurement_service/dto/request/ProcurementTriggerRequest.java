package com.erp.procurement_service.dto.request;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProcurementTriggerRequest {

    @NotNull(message = "Product ID is required")
    private Long productId;

    @NotNull(message = "Required quantity is required")
    @Min(value = 1, message = "Required quantity must be at least 1")
    private Integer requiredQty;

    @NotBlank(message = "Sales order number is required")
    private String salesOrderNumber;
}