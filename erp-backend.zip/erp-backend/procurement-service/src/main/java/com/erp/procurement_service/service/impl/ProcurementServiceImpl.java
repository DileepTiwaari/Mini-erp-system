package com.erp.procurement_service.service.impl;

import com.erp.procurement_service.client.InventoryServiceClient;
import com.erp.procurement_service.client.ProductServiceClient;
import com.erp.procurement_service.dto.request.ProcurementRuleUpdateRequest;
import com.erp.procurement_service.dto.request.ProcurementTriggerRequest;
import com.erp.procurement_service.dto.response.ProcurementLogResponse;
import com.erp.procurement_service.dto.response.ProcurementResponse;
import com.erp.procurement_service.entity.ProcurementLog;
import com.erp.procurement_service.exception.ProcurementException;
import com.erp.procurement_service.repository.ProcurementLogRepository;
import com.erp.procurement_service.service.interfaces.ProcurementService;
import com.erp.procurement_service.service.interfaces.ReplenishmentService;
import com.erp.procurement_service.util.ProcurementUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class ProcurementServiceImpl implements ProcurementService {

    private final ProductServiceClient productServiceClient;
    private final InventoryServiceClient inventoryServiceClient;
    private final ReplenishmentService replenishmentService;
    private final ProcurementLogRepository procurementLogRepository;

    @Override
    public ProcurementResponse triggerAutoProcurement(ProcurementTriggerRequest request) {
        ProductServiceClient.ProductDto product = productServiceClient.getProductById(request.getProductId());

        if (product == null) {
            throw new ProcurementException("Product not found: " + request.getProductId());
        }

        if (!Boolean.TRUE.equals(product.procureOnDemand())) {
            return ProcurementResponse.builder()
                    .procurementTriggered(false)
                    .type("NONE")
                    .shortage(request.getRequiredQty())
                    .reason("Procure-on-demand is disabled for this product")
                    .build();
        }

        int shortage = request.getRequiredQty();
        String actionTaken;
        String referenceId;
        String reason;

        if ("MANUFACTURING".equalsIgnoreCase(product.procurementType())) {
            referenceId = replenishmentService.createManufacturingOrder(
                    product.id(), shortage, product.bomId(),
                    ProcurementUtil.buildReason(request.getSalesOrderNumber(), shortage, "Manufacturing Order", null));
            actionTaken = "MANUFACTURING";
            reason = ProcurementUtil.buildReason(request.getSalesOrderNumber(), shortage, "MO", referenceId);
        } else {
            referenceId = replenishmentService.createPurchaseOrder(
                    product.id(), shortage, product.vendorId(),
                    ProcurementUtil.buildReason(request.getSalesOrderNumber(), shortage, "Purchase Order", null));
            actionTaken = "PURCHASE";
            reason = ProcurementUtil.buildReason(request.getSalesOrderNumber(), shortage, "PO", referenceId);
        }

        ProcurementLog log = ProcurementLog.builder()
                .productId(product.id())
                .shortageQty(shortage)
                .actionTaken(actionTaken)
                .referenceId(referenceId)
                .reason(reason)
                .build();
        procurementLogRepository.save(log);

        return ProcurementResponse.builder()
                .procurementTriggered(true)
                .type(actionTaken)
                .shortage(shortage)
                .referenceId(referenceId)
                .reason(reason)
                .build();
    }

    @Override
    public ProcurementResponse manualTrigger(ProcurementTriggerRequest request) {
        return triggerAutoProcurement(request);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Object> getRules() {
        ProductServiceClient.ApiListWrapper wrapper = productServiceClient.getAllProductsRaw(1000);
        if (wrapper == null || wrapper.data() == null) {
            return List.of();
        }
        return List.copyOf(wrapper.data().content());
    }

    @Override
    public void updateRule(Long productId, ProcurementRuleUpdateRequest request) {
        productServiceClient.updateProduct(productId, new ProductServiceClient.ProductUpdatePayload(
                request.getStrategy(), request.getType(), request.getVendorId(),
                request.getBomId(), request.getProcureOnDemand()));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ProcurementLogResponse> getHistory(Pageable pageable) {
        return procurementLogRepository.findAll(pageable).map(this::toResponse);
    }

    private ProcurementLogResponse toResponse(ProcurementLog log) {
        return ProcurementLogResponse.builder()
                .id(log.getId())
                .productId(log.getProductId())
                .shortageQty(log.getShortageQty())
                .actionTaken(log.getActionTaken())
                .referenceId(log.getReferenceId())
                .reason(log.getReason())
                .triggeredAt(log.getTriggeredAt())
                .triggeredBy(log.getTriggeredBy())
                .build();
    }
}