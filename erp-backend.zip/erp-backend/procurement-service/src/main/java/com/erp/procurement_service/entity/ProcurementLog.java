package com.erp.procurement_service.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "procurement_logs")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProcurementLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "product_id", nullable = false)
    private Long productId;

    @Column(name = "shortage_qty", nullable = false)
    private Integer shortageQty;

    @Column(name = "action_taken", length = 30)
    private String actionTaken; // PURCHASE / MANUFACTURING / NONE

    @Column(name = "reference_id", length = 50)
    private String referenceId;

    @Column(length = 500)
    private String reason;

    @Column(name = "triggered_at", updatable = false)
    private LocalDateTime triggeredAt;

    @Column(name = "triggered_by", length = 50)
    private String triggeredBy;

    @PrePersist
    protected void onCreate() {
        this.triggeredAt = LocalDateTime.now();
        if (this.triggeredBy == null) this.triggeredBy = "SYSTEM";
    }
}