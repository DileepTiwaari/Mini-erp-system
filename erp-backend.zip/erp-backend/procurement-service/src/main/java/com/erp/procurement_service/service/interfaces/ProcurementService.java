package com.erp.procurement_service.service.interfaces;

import com.erp.procurement_service.dto.request.ProcurementRuleUpdateRequest;
import com.erp.procurement_service.dto.request.ProcurementTriggerRequest;
import com.erp.procurement_service.dto.response.ProcurementLogResponse;
import com.erp.procurement_service.dto.response.ProcurementResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ProcurementService {

    ProcurementResponse triggerAutoProcurement(ProcurementTriggerRequest request);

    ProcurementResponse manualTrigger(ProcurementTriggerRequest request);

    List<Object> getRules();

    void updateRule(Long productId, ProcurementRuleUpdateRequest request);

    Page<ProcurementLogResponse> getHistory(Pageable pageable);
}