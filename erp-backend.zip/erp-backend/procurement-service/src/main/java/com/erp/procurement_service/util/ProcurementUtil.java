package com.erp.procurement_service.util;

public class ProcurementUtil {

    private ProcurementUtil() {
    }

    public static String buildReason(String orderNumber, int shortage, String action, String refNumber) {
        return String.format("%s created because %s generated shortage of %d units (ref: %s)",
                action, orderNumber, shortage, refNumber);
    }
}