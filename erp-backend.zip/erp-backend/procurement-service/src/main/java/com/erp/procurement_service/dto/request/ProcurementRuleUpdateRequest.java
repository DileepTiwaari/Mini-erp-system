package com.erp.procurement_service.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProcurementRuleUpdateRequest {

    @NotBlank(message = "Procurement strategy is required (MTS or MTO)")
    private String strategy;

    @NotBlank(message = "Procurement type is required (PURCHASE or MANUFACTURING)")
    private String type;

    private Long vendorId;

    private Long bomId;

    private Boolean procureOnDemand;
}