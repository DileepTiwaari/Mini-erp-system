package com.erp.procurement_service.dto.response;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProcurementResponse {
    private Boolean procurementTriggered;
    private String type;
    private Integer shortage;
    private String referenceId;
    private String reason;
}