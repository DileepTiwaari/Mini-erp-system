package com.erp.procurement_service.dto.response;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProcurementLogResponse {
    private Long id;
    private Long productId;
    private Integer shortageQty;
    private String actionTaken;
    private String referenceId;
    private String reason;
    private LocalDateTime triggeredAt;
    private String triggeredBy;
}