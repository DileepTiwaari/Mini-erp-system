package com.erp.procurement_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@FeignClient(name = "product-service")
public interface ProductServiceClient {

    @GetMapping("/api/v1/products/{id}")
    ProductDto getProductById(@PathVariable("id") Long id);

    @GetMapping("/api/v1/products")
    ApiListWrapper getAllProductsRaw(@RequestParam(value = "size", defaultValue = "1000") int size);

    @PutMapping("/api/v1/products/{id}")
    void updateProduct(@PathVariable("id") Long id, @RequestBody ProductUpdatePayload payload);

    record ProductDto(
            Long id,
            String sku,
            String name,
            BigDecimal salesPrice,
            BigDecimal costPrice,
            String procurementType,
            String procurementStrategy,
            Boolean procureOnDemand,
            Long vendorId,
            Long bomId
    ) {}

    record ProductUpdatePayload(
            String procurementStrategy,
            String procurementType,
            Long vendorId,
            Long bomId,
            Boolean procureOnDemand
    ) {}

    record ApiListWrapper(boolean success, String message, PageWrapper data) {}

    record PageWrapper(List<ProductDto> content) {}
}