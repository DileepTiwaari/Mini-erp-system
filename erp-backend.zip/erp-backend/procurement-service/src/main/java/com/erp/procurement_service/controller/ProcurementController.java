package com.erp.procurement_service.controller;

import com.erp.procurement_service.dto.request.ProcurementRuleUpdateRequest;
import com.erp.procurement_service.dto.request.ProcurementTriggerRequest;
import com.erp.procurement_service.dto.response.ApiResponse;
import com.erp.procurement_service.dto.response.ProcurementLogResponse;
import com.erp.procurement_service.dto.response.ProcurementResponse;
import com.erp.procurement_service.service.interfaces.ProcurementService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/procurement")
@RequiredArgsConstructor
public class ProcurementController {

    private final ProcurementService procurementService;

    @PostMapping("/trigger")
    public ApiResponse<ProcurementResponse> manualTrigger(@Valid @RequestBody ProcurementTriggerRequest request) {
        return ApiResponse.success("Procurement evaluated", procurementService.manualTrigger(request));
    }

    @PostMapping("/auto")
    public ProcurementResponse autoTrigger(@Valid @RequestBody ProcurementTriggerRequest request) {
        // Internal endpoint called by sales-service — returns raw DTO (not wrapped)
        // so the SalesService Feign client can deserialize it directly.
        return procurementService.triggerAutoProcurement(request);
    }

    @GetMapping("/rules")
    public ApiResponse<List<Object>> getRules() {
        return ApiResponse.success(procurementService.getRules());
    }

    @PutMapping("/rules/{productId}")
    public ApiResponse<Void> updateRule(
            @PathVariable Long productId, @Valid @RequestBody ProcurementRuleUpdateRequest request) {
        procurementService.updateRule(productId, request);
        return ApiResponse.success("Procurement rule updated successfully", null);
    }

    @GetMapping("/history")
    public ApiResponse<Page<ProcurementLogResponse>> getHistory(
            @PageableDefault(size = 20, sort = "triggeredAt") Pageable pageable) {
        return ApiResponse.success(procurementService.getHistory(pageable));
    }
}