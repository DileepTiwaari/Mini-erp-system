package com.erp.procurement_service.service.impl;

import com.erp.procurement_service.client.ManufacturingServiceClient;
import com.erp.procurement_service.client.PurchaseServiceClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ReplenishmentServiceImpl implements com.erp.procurement_service.service.interfaces.ReplenishmentService {

    private final PurchaseServiceClient purchaseServiceClient;
    private final ManufacturingServiceClient manufacturingServiceClient;

    @Override
    public String createPurchaseOrder(Long productId, Integer qty, Long vendorId, String reason) {
        PurchaseServiceClient.PurchaseOrderAutoResponse response =
                purchaseServiceClient.createAutoPurchaseOrder(
                        new PurchaseServiceClient.PurchaseOrderAutoRequest(productId, qty, vendorId, reason));
        return response != null ? response.poNumber() : null;
    }

    @Override
    public String createManufacturingOrder(Long productId, Integer qty, Long bomId, String reason) {
        ManufacturingServiceClient.ManufacturingOrderAutoResponse response =
                manufacturingServiceClient.createAutoManufacturingOrder(
                        new ManufacturingServiceClient.ManufacturingOrderAutoRequest(productId, qty, bomId, reason));
        return response != null ? response.moNumber() : null;
    }
}