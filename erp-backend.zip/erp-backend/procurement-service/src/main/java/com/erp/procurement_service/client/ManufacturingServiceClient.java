package com.erp.procurement_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "manufacturing-service")
public interface ManufacturingServiceClient {

    @PostMapping("/api/v1/manufacturing-orders/auto-create")
    ManufacturingOrderAutoResponse createAutoManufacturingOrder(@RequestBody ManufacturingOrderAutoRequest request);

    record ManufacturingOrderAutoRequest(
            Long productId,
            Integer qty,
            Long bomId,
            String reason
    ) {}

    record ManufacturingOrderAutoResponse(
            String moNumber,
            Long manufacturingOrderId
    ) {}
}