package com.erp.procurement_service.service.interfaces;

public interface ReplenishmentService {

    String createPurchaseOrder(Long productId, Integer qty, Long vendorId, String reason);

    String createManufacturingOrder(Long productId, Integer qty, Long bomId, String reason);
}