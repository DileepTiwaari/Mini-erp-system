package com.erp.procurement_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "purchase-service")
public interface PurchaseServiceClient {

    @PostMapping("/api/v1/purchase-orders/auto-create")
    PurchaseOrderAutoResponse createAutoPurchaseOrder(@RequestBody PurchaseOrderAutoRequest request);

    record PurchaseOrderAutoRequest(
            Long productId,
            Integer qty,
            Long vendorId,
            String reason
    ) {}

    record PurchaseOrderAutoResponse(
            String poNumber,
            Long purchaseOrderId
    ) {}
}