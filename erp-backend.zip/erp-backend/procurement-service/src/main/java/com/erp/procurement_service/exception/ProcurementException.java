package com.erp.procurement_service.exception;

public class ProcurementException extends RuntimeException {

    public ProcurementException(String message) {
        super(message);
    }
}