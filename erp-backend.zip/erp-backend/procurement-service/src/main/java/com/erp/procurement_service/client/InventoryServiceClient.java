package com.erp.procurement_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "inventory-service")
public interface InventoryServiceClient {

    @GetMapping("/api/v1/stock/{productId}")
    StockDto getStock(@PathVariable("productId") Long productId);

    record StockDto(
            Long productId,
            Integer onHandQty,
            Integer reservedQty,
            Integer freeToUseQty
    ) {}
}