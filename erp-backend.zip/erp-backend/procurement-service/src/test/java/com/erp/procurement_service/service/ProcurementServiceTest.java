package com.erp.procurement_service.service;

import org.junit.jupiter.api.Test;

class ProcurementServiceTest {
    @Test
    void placeholderTest() {
    }
}