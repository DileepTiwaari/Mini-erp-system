package com.erp.audit_service.service;

import org.junit.jupiter.api.Test;

class AuditServiceTest {
    @Test
    void placeholderTest() {
    }
}