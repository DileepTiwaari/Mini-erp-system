package com.erp.audit_service.controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuditControllerTest {
    @Test
    void contextLoads() {
    }
}