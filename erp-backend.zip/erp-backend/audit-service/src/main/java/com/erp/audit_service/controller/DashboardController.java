package com.erp.audit_service.controller;

import com.erp.audit_service.dto.response.ApiResponse;
import com.erp.audit_service.dto.response.AuditLogResponse;
import com.erp.audit_service.dto.response.DashboardResponse;
import com.erp.audit_service.service.interfaces.DashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/dashboard")
@RequiredArgsConstructor
public class DashboardController {

    private final DashboardService dashboardService;

    @GetMapping
    public ApiResponse<DashboardResponse> getDashboard() {
        return ApiResponse.success(dashboardService.getDashboard());
    }

    @GetMapping("/sales-summary")
    public ApiResponse<Map<String, Long>> getSalesSummary() {
        return ApiResponse.success(dashboardService.getSalesSummary());
    }

    @GetMapping("/manufacturing-summary")
    public ApiResponse<Map<String, Long>> getManufacturingSummary() {
        return ApiResponse.success(dashboardService.getManufacturingSummary());
    }

    @GetMapping("/stock-alerts")
    public ApiResponse<List<Object>> getStockAlerts() {
        return ApiResponse.success(dashboardService.getStockAlerts());
    }

    @GetMapping("/recent-activities")
    public ApiResponse<List<AuditLogResponse>> getRecentActivities() {
        return ApiResponse.success(dashboardService.getRecentActivities());
    }
}