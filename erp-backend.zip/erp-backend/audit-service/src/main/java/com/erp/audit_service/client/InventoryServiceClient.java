package com.erp.audit_service.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(name = "inventory-service")
public interface InventoryServiceClient {

    @GetMapping("/api/v1/stock/low-stock")
    ApiListResponse getLowStockProducts(@RequestParam(value = "threshold", defaultValue = "10") int threshold);

    @JsonIgnoreProperties(ignoreUnknown = true)
    record ApiListResponse(boolean success, String message, List<Object> data) {}
}