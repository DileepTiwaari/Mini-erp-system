package com.erp.audit_service.service.interfaces;

import com.erp.audit_service.dto.response.AuditLogResponse;
import com.erp.audit_service.dto.response.DashboardResponse;

import java.util.List;
import java.util.Map;

public interface DashboardService {

    DashboardResponse getDashboard();

    Map<String, Long> getSalesSummary();

    Map<String, Long> getManufacturingSummary();

    List<Object> getStockAlerts();

    List<AuditLogResponse> getRecentActivities();
}