package com.erp.audit_service.service.impl;

import com.erp.audit_service.client.InventoryServiceClient;
import com.erp.audit_service.client.ManufacturingServiceClient;
import com.erp.audit_service.client.PurchaseServiceClient;
import com.erp.audit_service.client.SalesServiceClient;
import com.erp.audit_service.dto.response.AuditLogResponse;
import com.erp.audit_service.dto.response.DashboardResponse;
import com.erp.audit_service.repository.AuditLogRepository;
import com.erp.audit_service.service.interfaces.DashboardService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class DashboardServiceImpl implements DashboardService {

    private final SalesServiceClient salesServiceClient;
    private final PurchaseServiceClient purchaseServiceClient;
    private final ManufacturingServiceClient manufacturingServiceClient;
    private final InventoryServiceClient inventoryServiceClient;
    private final AuditLogRepository auditLogRepository;

    @Override
    public DashboardResponse getDashboard() {
        return DashboardResponse.builder()
                .totalSalesOrders(safeTotalSalesOrders())
                .pendingDeliveries(safePendingDeliveries())
                .totalPurchaseOrders(safeTotalPurchaseOrders())
                .partialReceipts(safePartialReceipts())
                .manufacturingOrders(safeManufacturingOrders())
                .delayedOrders(0L) // ⚠️ Business rule for "delayed" not yet finalized — placeholder
                .lowStockProducts(safeLowStockCount())
                .build();
    }

    @Override
    public Map<String, Long> getSalesSummary() {
        Map<String, Long> summary = new HashMap<>();
        String[] statuses = {"DRAFT", "CONFIRMED", "PARTIALLY_DELIVERED", "FULLY_DELIVERED", "CANCELLED"};
        for (String status : statuses) {
            try {
                summary.put(status, salesServiceClient.getAllSalesOrders(status, 1).data().totalElements());
            } catch (Exception ex) {
                log.warn("Failed to fetch sales summary for status {}: {}", status, ex.getMessage());
                summary.put(status, 0L);
            }
        }
        return summary;
    }

    @Override
    public Map<String, Long> getManufacturingSummary() {
        Map<String, Long> summary = new HashMap<>();
        String[] statuses = {"DRAFT", "CONFIRMED", "IN_PROGRESS", "DONE", "CANCELLED"};
        for (String status : statuses) {
            try {
                summary.put(status, manufacturingServiceClient.getAllManufacturingOrders(status, 1).data().totalElements());
            } catch (Exception ex) {
                log.warn("Failed to fetch manufacturing summary for status {}: {}", status, ex.getMessage());
                summary.put(status, 0L);
            }
        }
        return summary;
    }

    @Override
    public List<Object> getStockAlerts() {
        try {
            return inventoryServiceClient.getLowStockProducts(10).data();
        } catch (Exception ex) {
            log.warn("Failed to fetch stock alerts: {}", ex.getMessage());
            return Collections.emptyList();
        }
    }

    @Override
    public List<AuditLogResponse> getRecentActivities() {
        return auditLogRepository.findAllByOrderByPerformedAtDesc(PageRequest.of(0, 20))
                .stream()
                .map(log -> AuditLogResponse.builder()
                        .id(log.getId())
                        .module(log.getModule())
                        .entityId(log.getEntityId())
                        .entityType(log.getEntityType())
                        .action(log.getAction())
                        .performedBy(log.getPerformedBy())
                        .performedAt(log.getPerformedAt())
                        .build())
                .collect(Collectors.toList());
    }

    private long safeTotalSalesOrders() {
        try {
            return salesServiceClient.getAllSalesOrders(null, 1).data().totalElements();
        } catch (Exception ex) {
            log.warn("Failed to fetch total sales orders: {}", ex.getMessage());
            return 0L;
        }
    }

    private long safePendingDeliveries() {
        try {
            return salesServiceClient.getPendingDeliveries().data().size();
        } catch (Exception ex) {
            log.warn("Failed to fetch pending deliveries: {}", ex.getMessage());
            return 0L;
        }
    }

    private long safeTotalPurchaseOrders() {
        try {
            return purchaseServiceClient.getAllPurchaseOrders(null, 1).data().totalElements();
        } catch (Exception ex) {
            log.warn("Failed to fetch total purchase orders: {}", ex.getMessage());
            return 0L;
        }
    }

    private long safePartialReceipts() {
        try {
            return purchaseServiceClient.getPendingReceipts().data().size();
        } catch (Exception ex) {
            log.warn("Failed to fetch partial receipts: {}", ex.getMessage());
            return 0L;
        }
    }

    private long safeManufacturingOrders() {
        try {
            return manufacturingServiceClient.getAllManufacturingOrders(null, 1).data().totalElements();
        } catch (Exception ex) {
            log.warn("Failed to fetch manufacturing orders: {}", ex.getMessage());
            return 0L;
        }
    }

    private long safeLowStockCount() {
        try {
            return inventoryServiceClient.getLowStockProducts(10).data().size();
        } catch (Exception ex) {
            log.warn("Failed to fetch low stock count: {}", ex.getMessage());
            return 0L;
        }
    }
}