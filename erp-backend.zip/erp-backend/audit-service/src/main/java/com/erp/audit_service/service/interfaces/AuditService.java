package com.erp.audit_service.service.interfaces;

import com.erp.audit_service.dto.request.AuditLogRequest;
import com.erp.audit_service.dto.response.AuditLogResponse;
import com.erp.audit_service.enums.AuditModule;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface AuditService {

    AuditLogResponse createLog(AuditLogRequest request);

    AuditLogResponse getLogById(Long id);

    Page<AuditLogResponse> getLogs(AuditModule module, Pageable pageable);

    Page<AuditLogResponse> getLogsByEntity(String entityId, Pageable pageable);

    Page<AuditLogResponse> getLogsByUser(String userId, Pageable pageable);
}