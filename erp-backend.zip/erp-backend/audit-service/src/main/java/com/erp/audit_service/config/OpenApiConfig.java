package com.erp.audit_service.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI auditServiceOpenApi() {
        return new OpenAPI()
                .info(new Info()
                        .title("Audit Service API")
                        .version("1.0.0")
                        .description("Mini ERP — Audit trail and business dashboard"));
    }
}