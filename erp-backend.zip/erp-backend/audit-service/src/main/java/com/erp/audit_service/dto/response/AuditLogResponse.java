package com.erp.audit_service.dto.response;

import com.erp.audit_service.enums.AuditAction;
import com.erp.audit_service.enums.AuditModule;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditLogResponse {
    private Long id;
    private AuditModule module;
    private String entityId;
    private String entityType;
    private AuditAction action;
    private String oldValue;
    private String newValue;
    private String performedBy;
    private LocalDateTime performedAt;
}