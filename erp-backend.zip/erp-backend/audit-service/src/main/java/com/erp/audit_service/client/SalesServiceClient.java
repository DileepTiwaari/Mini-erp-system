package com.erp.audit_service.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * NOTE: sales-service returns paginated data wrapped as
 * ApiResponse<Page<SalesOrderResponse>>. Feign cannot deserialize Page<T>
 * directly, so these wrapper records only read the fields they need
 * (e.g. totalElements) and ignore the rest of the JSON payload.
 */
@FeignClient(name = "sales-service")
public interface SalesServiceClient {

    @GetMapping("/api/v1/sales-orders")
    ApiPageResponse getAllSalesOrders(@RequestParam(value = "status", required = false) String status,
                                      @RequestParam(value = "size", defaultValue = "1") int size);

    @GetMapping("/api/v1/sales-orders/pending-deliveries")
    ApiListResponse getPendingDeliveries();

    @JsonIgnoreProperties(ignoreUnknown = true)
    record ApiPageResponse(boolean success, String message, PageData data) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    record PageData(long totalElements) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    record ApiListResponse(boolean success, String message, List<Object> data) {}
}