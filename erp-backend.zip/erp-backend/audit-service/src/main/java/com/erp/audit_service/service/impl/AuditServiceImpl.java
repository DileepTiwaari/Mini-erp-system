package com.erp.audit_service.service.impl;

import com.erp.audit_service.dto.request.AuditLogRequest;
import com.erp.audit_service.dto.response.AuditLogResponse;
import com.erp.audit_service.entity.AuditLog;
import com.erp.audit_service.enums.AuditModule;
import com.erp.audit_service.exception.AuditException;
import com.erp.audit_service.repository.AuditLogRepository;
import com.erp.audit_service.service.interfaces.AuditService;
import com.erp.audit_service.util.AuditUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class AuditServiceImpl implements AuditService {

    private final AuditLogRepository auditLogRepository;

    @Override
    public AuditLogResponse createLog(AuditLogRequest request) {
        AuditLog log = AuditLog.builder()
                .module(request.getModule())
                .entityId(request.getEntityId())
                .entityType(request.getEntityType())
                .action(request.getAction())
                .oldValue(AuditUtil.truncate(request.getOldValue(), 4000))
                .newValue(AuditUtil.truncate(request.getNewValue(), 4000))
                .performedBy(request.getPerformedBy() != null ? request.getPerformedBy() : "SYSTEM")
                .build();

        return toResponse(auditLogRepository.save(log));
    }

    @Override
    @Transactional(readOnly = true)
    public AuditLogResponse getLogById(Long id) {
        AuditLog log = auditLogRepository.findById(id)
                .orElseThrow(() -> new AuditException("Audit log not found with id: " + id));
        return toResponse(log);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<AuditLogResponse> getLogs(AuditModule module, Pageable pageable) {
        Page<AuditLog> page = (module != null)
                ? auditLogRepository.findByModule(module, pageable)
                : auditLogRepository.findAll(pageable);
        return page.map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<AuditLogResponse> getLogsByEntity(String entityId, Pageable pageable) {
        return auditLogRepository.findByEntityId(entityId, pageable).map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<AuditLogResponse> getLogsByUser(String userId, Pageable pageable) {
        return auditLogRepository.findByPerformedBy(userId, pageable).map(this::toResponse);
    }

    private AuditLogResponse toResponse(AuditLog log) {
        return AuditLogResponse.builder()
                .id(log.getId())
                .module(log.getModule())
                .entityId(log.getEntityId())
                .entityType(log.getEntityType())
                .action(log.getAction())
                .oldValue(log.getOldValue())
                .newValue(log.getNewValue())
                .performedBy(log.getPerformedBy())
                .performedAt(log.getPerformedAt())
                .build();
    }
}