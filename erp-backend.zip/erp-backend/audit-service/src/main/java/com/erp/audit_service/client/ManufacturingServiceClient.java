package com.erp.audit_service.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "manufacturing-service")
public interface ManufacturingServiceClient {

    @GetMapping("/api/v1/manufacturing-orders")
    ApiPageResponse getAllManufacturingOrders(@RequestParam(value = "status", required = false) String status,
                                              @RequestParam(value = "size", defaultValue = "1") int size);

    @JsonIgnoreProperties(ignoreUnknown = true)
    record ApiPageResponse(boolean success, String message, PageData data) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    record PageData(long totalElements) {}
}