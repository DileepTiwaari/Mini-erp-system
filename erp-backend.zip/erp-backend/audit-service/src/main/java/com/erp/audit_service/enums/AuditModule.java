package com.erp.audit_service.enums;

public enum AuditModule {
    SALES,
    PURCHASE,
    MANUFACTURING,
    INVENTORY,
    PRODUCT,
    AUTH
}