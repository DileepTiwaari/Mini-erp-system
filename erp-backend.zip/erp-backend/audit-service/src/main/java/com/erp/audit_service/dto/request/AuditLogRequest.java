package com.erp.audit_service.dto.request;

import com.erp.audit_service.enums.AuditAction;
import com.erp.audit_service.enums.AuditModule;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuditLogRequest {

    @NotNull(message = "Module is required")
    private AuditModule module;

    @NotNull(message = "Entity ID is required")
    private String entityId;

    private String entityType;

    @NotNull(message = "Action is required")
    private AuditAction action;

    private String oldValue;

    private String newValue;

    private String performedBy;
}