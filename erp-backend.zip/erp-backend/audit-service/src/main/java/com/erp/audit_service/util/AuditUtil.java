package com.erp.audit_service.util;

public class AuditUtil {

    private AuditUtil() {
    }

    public static String truncate(String value, int maxLength) {
        if (value == null) return null;
        return value.length() > maxLength ? value.substring(0, maxLength) : value;
    }
}