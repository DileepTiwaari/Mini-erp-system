package com.erp.audit_service.controller;

import com.erp.audit_service.dto.request.AuditLogRequest;
import com.erp.audit_service.dto.response.ApiResponse;
import com.erp.audit_service.dto.response.AuditLogResponse;
import com.erp.audit_service.enums.AuditModule;
import com.erp.audit_service.service.interfaces.AuditService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/audit/logs")
@RequiredArgsConstructor
public class AuditController {

    private final AuditService auditService;

    @GetMapping
    public ApiResponse<Page<AuditLogResponse>> getLogs(
            @RequestParam(required = false) AuditModule module,
            @PageableDefault(size = 20, sort = "performedAt") Pageable pageable) {
        return ApiResponse.success(auditService.getLogs(module, pageable));
    }

    @GetMapping("/{id}")
    public ApiResponse<AuditLogResponse> getLogById(@PathVariable Long id) {
        return ApiResponse.success(auditService.getLogById(id));
    }

    @GetMapping("/entity/{entityId}")
    public ApiResponse<Page<AuditLogResponse>> getLogsByEntity(
            @PathVariable String entityId,
            @PageableDefault(size = 20, sort = "performedAt") Pageable pageable) {
        return ApiResponse.success(auditService.getLogsByEntity(entityId, pageable));
    }

    @GetMapping("/user/{userId}")
    public ApiResponse<Page<AuditLogResponse>> getLogsByUser(
            @PathVariable String userId,
            @PageableDefault(size = 20, sort = "performedAt") Pageable pageable) {
        return ApiResponse.success(auditService.getLogsByUser(userId, pageable));
    }

    @PostMapping
    public ApiResponse<AuditLogResponse> createLog(@Valid @RequestBody AuditLogRequest request) {
        return ApiResponse.success("Audit log created", auditService.createLog(request));
    }
}