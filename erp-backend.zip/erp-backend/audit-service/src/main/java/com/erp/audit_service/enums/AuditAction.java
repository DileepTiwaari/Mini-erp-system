package com.erp.audit_service.enums;

public enum AuditAction {
    CREATED,
    UPDATED,
    DELETED,
    STATUS_CHANGED,
    DELIVERED,
    RECEIVED,
    COMPLETED
}