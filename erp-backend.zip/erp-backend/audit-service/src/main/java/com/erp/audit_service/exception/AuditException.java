package com.erp.audit_service.exception;

public class AuditException extends RuntimeException {

    public AuditException(String message) {
        super(message);
    }
}