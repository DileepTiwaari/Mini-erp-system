package com.erp.audit_service.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(name = "purchase-service")
public interface PurchaseServiceClient {

    @GetMapping("/api/v1/purchase-orders")
    ApiPageResponse getAllPurchaseOrders(@RequestParam(value = "status", required = false) String status,
                                         @RequestParam(value = "size", defaultValue = "1") int size);

    @GetMapping("/api/v1/purchase-orders/pending-receipts")
    ApiListResponse getPendingReceipts();

    @JsonIgnoreProperties(ignoreUnknown = true)
    record ApiPageResponse(boolean success, String message, PageData data) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    record PageData(long totalElements) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    record ApiListResponse(boolean success, String message, List<Object> data) {}
}