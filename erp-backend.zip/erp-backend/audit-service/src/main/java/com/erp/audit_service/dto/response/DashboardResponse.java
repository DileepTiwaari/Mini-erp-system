package com.erp.audit_service.dto.response;

import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DashboardResponse {
    private long totalSalesOrders;
    private long pendingDeliveries;
    private long totalPurchaseOrders;
    private long partialReceipts;
    private long manufacturingOrders;
    private long delayedOrders;
    private long lowStockProducts;
}