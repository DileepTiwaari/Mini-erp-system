-- V1: Create audit_logs table
CREATE TABLE audit_logs (
                            id BIGINT AUTO_INCREMENT PRIMARY KEY,
                            module VARCHAR(30) NOT NULL,
                            entity_id VARCHAR(50),
                            entity_type VARCHAR(50),
                            action VARCHAR(30) NOT NULL,
                            old_value TEXT,
                            new_value TEXT,
                            performed_by VARCHAR(50),
                            performed_at DATETIME NOT NULL
);

CREATE INDEX idx_audit_module ON audit_logs(module);
CREATE INDEX idx_audit_entity ON audit_logs(entity_id);
CREATE INDEX idx_audit_performed_by ON audit_logs(performed_by);
CREATE INDEX idx_audit_performed_at ON audit_logs(performed_at);